---
title: "Trama"
node_type: "rule"
summary: "Forma construída de Canalização: uma Dobra pequena e temporária organizada para produzir um efeito definido."
status: "review"
visibility: "workspace"
icon: "route"
aliases: ["Tramas"]
tags: ["síntese","revisão-editorial","cânone-conectado"]
properties: {"canon_layer":"cross_source_synthesis","review_required":true,"source_documents":["Arden ~ TdV(1).docx","Livro de Regras ~ TdV(3).docx","Urdidura do Vazio ~ TdV(1).docx"],"editorial_rule":"direct_sources_prevail","superseded_by":"tdv-ii-v2","rules_edition":"historical-v1"}
---
> **Histórico da edição anterior.** Não aplique seus números ou procedimentos ao TdV II. Consulte [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# Trama

> **Camada editorial:** síntese transversal em revisão. A formulação reúne conexões entre fontes finais; as transcrições canônicas permanecem separadas e rastreáveis.

Forma construída de Canalização: uma Dobra pequena e temporária organizada para produzir um efeito definido.

## Fontes principais

- [[../00-fontes/arden|Fonte — Arden]]
- [[../00-fontes/regras|Fonte — Livro de Regras]]
- [[../00-fontes/urdidura|Fonte — Urdidura do Vazio]]

## Conexões

As relações estruturadas deste verbete estão registradas no grafo do Nexus.
