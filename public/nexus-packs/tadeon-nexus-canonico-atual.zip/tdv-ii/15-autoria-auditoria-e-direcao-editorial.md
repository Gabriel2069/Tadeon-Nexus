---
title: "TdV II · Autoria, auditoria e direção editorial"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "AUTORIA, AUDITORIA E DIREÇÃO EDITORIAL", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# AUTORIA, AUDITORIA E DIREÇÃO EDITORIAL

Referência de leitura e consulta para a mesa.

## APÊNDICE D.1Matriz de verificação para criação de conteúdo

Use este instrumento ao criar uma nova Trama, Lavor, Fragmento, Condição ou Ameaça. O objetivo é impedir que a regra seja apenas um nome próprio para um bônus genérico.

[2688 TABLE]

Critério | Pergunta | Condição de aprovação

Origem | Qual fenômeno existente é especializado? | Referência a um capítulo ou regra-base

Relação | O que liga o efeito a seu alvo? | Dependência e permissão identificáveis

Intenção | Que mudança a ação produz? | Efeito observável e finito

Resolução | Quando rolar e qual limiar usar? | Motor ordinário ou exceção explícita

Custo | O que é consumido ou colocado em risco? | Sem bônus escondido e sem custo universal fictício

Limite | O que a expressão não consegue fazer? | Fronteira legível na mesa

Persistência | O que sobra e quando acaba? | Duração, manutenção ou Resto definido

Contradições | Duplica efeito já coberto por outra regra? | Especializa ou remete, sem concorrer

## Acordos de intensidade e participação

Antes da campanha, o grupo estabelece temas que não entram em jogo, temas tratados fora de cena e uma forma simples de pausar ou reduzir a intensidade. Qualquer participante pode pedir mudança sem explicar uma experiência pessoal. Rever esses acordos durante a campanha não altera a autoridade das personagens sobre suas escolhas.

Consequências permanentes são construídas com o jogador. Um Conflito social pode mudar acesso, reputação, compromisso e relações; uma rolagem não determina automaticamente a intimidade, a Convicção ou a decisão final de uma personagem jogadora. Uma influência extraordinária só limita sua ação conforme efeito, duração e saída explicitamente descritos. Horror exige pressão ficcional que o grupo possa escolher atravessar.

## APÊNDICE D.2Matriz de narração ~ três velocidades de regra

Ação breve: declarar, escolher Fios, rolar, somar Enlace, reconhecer dupla unidade/Consonância, atualizar a situação.

Ação sob pressão: além do básico, declarar Posição, custo e Resposta; interpretar Ascendente, Retorno e Desvio quando modificarem a consequência.

Ação estrutural: explicitar dependências, etapas, Costuras, Frentes de Pressão e Restos que atravessarão a Cena. A complexidade vem da situação, não da exigência de cálculos extras para ações simples.

## APÊNDICE D.3Critério de precedência para casos não previstos

Quando uma situação não receber tratamento explícito, aplique em ordem: (1) permissão ficcional e definição do que pode mudar; (2) regra universal; (3) sistema derivado pertinente; (4) exceção específica nomeada e delimitada; (5) consequência e memória apropriadas. Uma regra particular pode substituir uma etapa da regra geral apenas quando sua redação indicar qual etapa e por quê.

Se houver ambiguidade real, a mesa escolhe uma interpretação, registra a decisão e a revisa entre sessões. A ambiguidade não deve ser explorada retroativamente para punir uma personagem ou alterar os resultados de uma rolagem já concluída.

## APÊNDICE D.4Guia de direção editorial ~ Fio~Mestre

A paleta e a tipografia nesta edição seguem o Fio~Mestre: EB Garamond na prosa, EB Garamond em abertura e títulos, Inter na informação técnica e PT Mono em registros e códigos; Vazio #080A0E, Reflexo #E9E3D5, Tinta #22262D, Medo #74242D, Conhecimento #D9D7A4 e Tempo #4F6E5D. Os diagramas são estudos de relações, e não reproduções da marca oficial.

Use marfim em páginas de leitura e escuro em divisões ou campos estruturais. O vermelho do Medo deve ser oxidado; o Conhecimento, amarelo-gélido, não dourado; o Tempo, verde de pátina, não verde vivo. Linhas têm origem, continuidade e consequência. Evite teias perfeitas, textura aleatória, símbolos ornamentais genéricos e fundos que prejudiquem a leitura.

### Vocabulário visual de função

•  Regra: enunciado normativo, precedido por sua condição de uso e seguido de procedimento.

•  Exemplo: demonstração claramente rotulada; não institui exceção.

•  Narrador: orientação para estabelecer limiares, condições e consequências.

•  Arquivo da Ordem: texto diegético identificado, que pode refletir conhecimento limitado de seus autores.

•  Dobra editorial: ressalva ou exceção que exige atenção adicional, sem abandonar a hierarquia tipográfica.

A identidade deve funcionar também sem cor. Cores orientam o olhar; números, palavras e estrutura continuam comunicando a regra em impressão monocromática e em leitores assistivos.
