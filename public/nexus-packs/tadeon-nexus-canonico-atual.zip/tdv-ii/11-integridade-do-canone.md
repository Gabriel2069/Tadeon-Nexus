---
title: "TdV II · Integridade do cânone"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "INTEGRIDADE DO CÂNONE", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# INTEGRIDADE DO CÂNONE

O mesmo mundo exige que suas regras saibam onde se encontrar.

A v2.0 é o corpo operacional definitivo do Documento Mestre. A ordem das partes segue dependência funcional; capítulos históricos não competem com essas regras.

## Precedência

1.  As Partes 0–10 e seus procedimentos canônicos regem a mesa.

2.  Uma regra específica de conteúdo só altera o núcleo quando declara explicitamente sua especialização.

3.  O Registro Histórico documenta versões, alternativas, auditorias e calibrações anteriores; não cria regra concorrente.

### Critério de fechamento

A arquitetura, o Motor, a economia de cena, as Relações, a Transformação, a Progressão e as principais derivações de conteúdo estão fechados. Catálogos e exemplos podem crescer sem abrir uma nova arquitetura.

Uma futura alteração só pertence à arquitetura se demonstrar uma falha real de funcionamento. Nesse caso, a alteração deve identificar a relação-pai, o problema que resolve, o resultado produzido e a parte do sistema que consome esse resultado.

A v2.0 não precisa de uma nova mecânica para cada situação. Ela já possui uma linguagem para derivar situações novas.

APÊNDICE A
