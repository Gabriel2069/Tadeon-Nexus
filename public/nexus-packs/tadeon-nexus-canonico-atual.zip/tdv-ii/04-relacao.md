---
title: "TdV II · Relação"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "RELAÇÃO", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# RELAÇÃO

VÍNCULO, COSTURA E RECONHECIMENTO

Nenhuma continuidade existe sozinha.

Como partes diferentes sustentam, condicionam, reconhecem ou rompem umas às outras.

## SEÇÃO 01TESTE CONJUNTO

Teste Conjunto é o nome geral de uma participação coordenada. Ele assume duas formas distintas, que não podem ser misturadas na mesma operação:

1.  Auxílio: uma pessoa executa a intenção principal e outra lhe oferece sustentação direta, fornecendo o Fio de Tento compatível de seu próprio Alinhavo. A protagonista oferece o Fio de Prumo de sua Matriz. Há um único teste de dois Fios, sem rolagem extra do auxiliar ou bônus automático de Enlace. O auxiliar participa do risco coerente com aquilo que sustentou.

2.  Cooperação: duas ou mais pessoas executam intervenções próprias e distintas, cada qual com sua Matriz, Alinhavo e teste. O grupo interpreta os resultados em conjunto; a falha de um participante não cancela automaticamente as conquistas dos demais.

A escolha é feita antes da rolagem. Se o auxílio não puder ocupar legitimamente o Tento da abordagem principal, a participação será Cooperação, Preparo ou simples contribuição ficcional. Auxiliar não é uma segunda ação gratuita; Impulso ou Resposta necessários são pagos conforme a situação, e uma personagem não auxilia ações independentes simultâneas sem autorização extraordinária.

Exemplo de Auxílio: alguém com Cadência d10 manuseia uma máquina sob orientação de colega com Engenharia d8. A ação usa Prumo d10 da pessoa que opera e Tento d8 da pessoa que auxilia. Não se rolam dois testes de Engenharia e não se concede Proveito automático.

Exemplo de Cooperação: uma pessoa desmonta a trava enquanto outra protege a porta e uma terceira procura a saída. Cada ação tem seu próprio teste e Resto. O que foi conquistado permanece, mesmo que uma das três falhe.

## SEÇÃO 02TESTES ENCADEADOS

Em uma sequência de etapas, cada etapa usa seus próprios dois Fios.

O resultado da etapa anterior modifica a situação da seguinte.

Um bom Enlace pode conceder Proveito.

Um Retorno relevante pode gerar Desproveito.

Um Desvio extremo pode alterar a abordagem necessária.

Consonância pode criar uma oportunidade extraordinária na etapa seguinte quando a relação entre as duas ações permitir.

Assim, o encadeamento registra continuidade sem criar uma fórmula nova.

## SEÇÃO 03TESTE FORÇADO

O antigo conceito de teste Forçado é absorvido por Forçar.

Não existe uma modalidade separada de teste.

A diferença é apenas a decisão de puxar um Fio antes da rolagem e aceitar o preço correspondente.

## SEÇÃO 04COSTURA, CONVERGÊNCIA, DESATAR E REPETIÇÃO

Costura é a relação pela qual partes diferentes passam a funcionar juntas para um propósito identificável. Não concede bônus numérico automático. Sua família contém:

•  Auxílio, em que uma ação usa Prumo da protagonista e Tento da pessoa que presta a ajuda, conforme o procedimento de Teste Conjunto;

•  Cooperação, em que cada participante efetua uma ação própria e os Restos contribuem para um propósito comum;

•  Costura de Malha, forma especializada pela qual uma personagem combina Lavores compatíveis, pagando ambos os preços e usando o Motor uma só vez salvo exceção explícita.

Convergência não é um quarto teste. Ela ocorre quando resultados independentes realmente passam a sustentar uma mesma mudança estrutural. Exemplo: desativar a iluminação, criar uma saída e distrair a vigilância fazem convergir Restos para uma rota de fuga. Nenhum dos três resultados recebe +1 ou Proveito apenas por receber o nome de Convergência.

Desatar rompe ou separa uma relação concreta, sem determinar sozinho o estado do que ficou separado. Desatar um hospedeiro de sua manifestação pode libertar o hospedeiro sem destruir a manifestação, deixando um novo Resto.

Regra da Repetição: não se repete um teste idêntico sobre a mesma intenção, com as mesmas condições, até surgir o resultado desejado. Outra intervenção só ocorre quando mudou Posição, ferramenta, informação, preparo, relação, objetivo ou Pressão de modo relevante.

Memória da Trama: ao fim da cena, anote apenas Restos persistentes cuja continuidade importa para situações futuras; indique a fonte, o estado atual e o que poderia encerrá-los. A Memória da Trama não gera uma barra adicional nem pontuação universal.

## SEÇÃO 05RECONHECIMENTO E REPUTAÇÃO

Reconhecimento é a resposta do mundo à trajetória de uma personagem. Desenvolvimento muda a pessoa; Reconhecimento muda a forma como outras pessoas, instituições e comunidades a tratam.

Não existe um segundo Rank universal.

Desenvolvimento pergunta: "O que mudou em mim?"

Reconhecimento pergunta: "O que o mundo espera de mim agora?"

### Reputação contextual

Reputação existe sempre em relação a um grupo, comunidade, instituição ou rede. Uma personagem pode ser referência entre investigadores e desconhecida entre comerciantes; admirada por uma comunidade e considerada perigosa por outra.

Cada Reputação relevante registra quatro elementos:

•  Rede ~ quem reconhece a personagem;

•  Imagem ~ pelo que ela é conhecida naquela rede;

•  Peso ~ quanta influência prática essa reputação possui;

•  Cobrança ~ o que essa reputação faz o mundo esperar dela.

Vínculos podem coexistir com Reputação, mas não são a mesma coisa. Vínculo descreve uma relação específica; Reputação descreve uma percepção distribuída por uma rede.

### Escala de Peso

Cada rede pode registrar um Peso de 0 a 4:

[0708 TABLE]

Peso | Estado | Significado

0 | Desconhecido | A rede não possui expectativa relevante sobre a personagem

1 | Conhecido | A personagem é reconhecida por algumas pessoas da rede

2 | Reconhecido | Sua atuação é conhecida e pode abrir portas reais

3 | Referência | Sua presença altera decisões, expectativas ou acesso dentro da rede

4 | Autoridade | Possui influência excepcional e cobrança proporcional

O Peso não concede bônus automático. Ele define o tamanho da resposta social possível.

### O que a Reputação faz

Quando a Reputação for pertinente, ela pode:

•  abrir acesso sem teste quando a expectativa da rede já resolver a barreira;

•  justificar uma abordagem que seria impossível para um desconhecido;

•  produzir Proveito quando a reputação realmente favorece a ação;

•  aumentar o alcance de uma consequência social;

•  fazer alguém reconhecer imediatamente a personagem;

•  criar expectativa, cobrança, vigilância ou oposição;

•  tornar uma ação pública mais perigosa porque o personagem não pode mais agir anonimamente.

A mesma reputação que abre uma porta pode criar uma dívida na porta seguinte.

### Ascensão e queda

O Peso sobe quando acontecimentos públicos ou relevantes consolidam a imagem da personagem. Não basta repetir uma ação em particular; a rede precisa reconhecer que aquilo mudou sua posição.

O Peso cai quando:

•  a personagem contradiz repetidamente a imagem estabelecida

•  uma falha pública altera confiança

•  outra pessoa ou instituição desmente sua autoridade

•  uma consequência torna a antiga reputação insustentável.

Uma queda de Peso deve produzir uma mudança ficcional correspondente. Não é punição numérica isolada.

### Reputações incompatíveis

Duas redes podem possuir imagens incompatíveis da mesma pessoa.

Exemplo:

•  uma instituição reconhece a personagem como especialista confiável

•  um grupo clandestino a considera colaboradora perigosa

•  uma comunidade local a vê como protetora.

Isso não é erro de ficha. É precisamente o tipo de contradição que Reconhecimento deve representar.

### Reputação e Conflitos

Em um Conflito social, a Reputação pode alterar a posição inicial, permitir acesso, criar Pressão ou fornecer Proveito. Ela não substitui o motor quando ainda existe disputa real.

Quando a reputação entra em choque com a situação, o resultado do teste pode mudar a própria reputação:

ação → exposição → resultado → resposta da rede → nova reputação.

Assim, Reconhecimento também funciona como memória social.

### Reputação e Vínculos

Um Vínculo pode ser a origem de uma Reputação, mas uma Reputação nunca cria automaticamente um Vínculo.

Uma pessoa pode conhecer "a fama" de um personagem sem possuir qualquer relação pessoal com ele. Da mesma forma, alguém pode manter um Vínculo profundo enquanto rejeita completamente sua reputação pública.

### Reconhecimento sem reputação

Nem todo personagem precisa possuir Reputação registrada. Se uma rede não tiver relevância para a campanha, não crie uma linha para ela.

O Narrador só registra Reputação quando ela começar a produzir decisões, acesso, cobrança ou consequência.

### Hierarquia da Relação

RELAÇÃO├── Vínculo├── Costura│   ├── Auxílio│   ├── Cooperação│   └── Costura de Malha├── Convergência├── Reconhecimento└── Desatar

Relação não é recurso. É a estrutura que explica como uma parte do sistema afeta outra.

## Costura e Convergência ~ a diferença que impede o acúmulo infinito

Costura ocorre durante uma intervenção: participantes, práticas ou materiais combinam sua contribuição para criar uma operação reconhecível. Convergência ocorre quando resultados já produzidos sustentam a mesma transformação ou passam a depender uns dos outros. A primeira diz como se faz junto; a segunda descreve o que se tornou conjuntamente possível. Nenhuma delas autoriza somar Enlaces de forma cumulativa sem regra explícita.

No Arquivo do Cais, Elen obtém acesso pela relação com a guardiã. Tomas estabiliza uma escora pela Engenharia. Iria encontra o registro pela Investigação. As três ações podem convergir para permitir acesso ao depósito sem jamais terem constituído um único teste conjunto. Se Tomas e Iria forem obrigados a operar o mesmo mecanismo enquanto a guardiã segura a porta, pode haver Costura: cada participante traz contribuição simultânea real para uma operação que não funcionaria isoladamente.

[0752 TABLE]

Situação | Leitura correta | Evitar

Uma ajudante ilumina o livro de registros, sem fornecer o método da leitura | Contribuição ficcional ou Preparo; pode justificar Proveito no Fio efetivamente favorecido | Somar seu Enlace ao teste do leitor

Duas especialistas executam operações distintas nos comandos de um mecanismo | Cooperação; distribuição funcional de participação | Somar Enlaces ou exigir testes redundantes para o mesmo risco

Três resultados diferentes abrem passagem | Convergência de consequências | Tratar tudo como um único bônus acumulativo

Um vínculo é rompido para encerrar um compromisso | Desatar com consequência relacional | Presumir apagamento de toda história compartilhada

### Da complementaridade à Incorporação na Malha de práticas

Quando dois Lavores aparecem na mesma cena, distingua complementaridade (duas aplicações independentes), Costura de Malha (expressão conjunta, dependente e paga segundo a regra correspondente) e Incorporação posterior (um Marco futuro pode legitimar aprendizado ou transformação). Nenhuma dessas situações concede automaticamente um novo Lavor ou PU. A mesma imagem de fios entrelaçados representa relações diferentes dependendo do que as sustenta.

PARTE IV
