---
title: "TdV II · Situação"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "SITUAÇÃO", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# SITUAÇÃO

CENA, POSIÇÃO, PRESSÃO E CONFLITO

A cena responde àquilo que os participantes conseguem mudar.

O estado compartilhado que recebe, resiste e responde às ações.

## SEÇÃO 01IMPULSOS E RESPOSTAS

A economia de cena do TdV II deve permitir que a personagem faça várias coisas sem transformar cada gesto em uma categoria rígida. Impulso mede a capacidade de produzir mudança dentro da rodada; Resposta mede a capacidade de reagir quando a situação muda por causa de outra pessoa.

### Rodada

Uma rodada é uma unidade de atenção compartilhada, não uma medida universal de segundos. Ela termina quando todos os participantes relevantes tiveram oportunidade de agir ou responder e então uma nova ordem é estabelecida.

Cada personagem possui, por padrão:

•  2 Impulsos por rodada;

•  1 Resposta por rodada.

Impulsos não acumulam entre rodadas. Os Impulsos disponíveis devem ser gastos naquela rodada ou são perdidos ao seu término. Nenhuma reserva retroativa é formada, salvo quando uma regra específica disser expressamente o contrário.

O valor de 2 Impulsos é a base de arquitetura. Ele pode ser alterado por Condição, Lavor, efeito extraordinário ou situação específica, mas o sistema não deve criar uma economia paralela para cada tipo de cena.

A regra central é simples:

Um Impulso produz uma mudança. Dois Impulsos podem sustentar uma ação exigente.

### Custo dos Impulsos

A maioria das ações relevantes consome 1 Impulso.

Uma ação pode consumir 2 Impulsos quando exige uma continuidade que não cabe razoavelmente em uma única oportunidade de intervenção. Exemplos:

•  atravessar uma exposição extensa enquanto mantém uma operação delicada;

•  realizar uma manobra física exigente;

•  executar uma Tecitura que demande atenção contínua;

•  operar equipamento complexo sob pressão;

•  conduzir uma ação cuja própria ficção indique esforço prolongado dentro da rodada.

O custo de 2 não significa "ação completa" universal. Significa que a personagem está comprometendo sua rodada inteira com aquela mudança.

Uma ação que pode ser realizada como parte natural de outra não precisa consumir um Impulso separado. Falar uma frase durante uma negociação, abrir uma porta já alcançada ou sacar um objeto acessível podem estar contidos no próprio gesto da ação.

O Narrador deve cobrar Impulso quando houver uma mudança real de posição, objetivo ou situação, e não por cada detalhe físico da descrição.

### O que um Impulso pode fazer

Um Impulso pode:

•  deslocar-se ou alterar distância;

•  atacar ou intervir sobre alguém;

•  proteger, cobrir ou preparar uma posição;

•  manipular objeto ou ambiente;

•  iniciar, continuar ou concluir uma operação;

•  investigar uma frente da situação;

•  influenciar uma pessoa ou grupo;

•  criar, explorar ou transferir uma abertura;

•  preparar uma ação futura;

•  sustentar uma Trama ou outro efeito quando sua regra exigir ação;

•  produzir qualquer mudança comparável que a ficção permita.

A lista não é uma lista de ações fechada. Ela descreve o tamanho de uma intervenção.

### Preparar

Preparar é uma forma importante de Impulso. A personagem declara uma condição que pretende deixar pronta para uma ação posterior.

Uma preparação deve registrar:

1.  o que está sendo preparado;

2.  para qual gatilho ou oportunidade;

3.  qual mudança ela permitirá.

Quando o gatilho ocorre, a preparação pode:

•  conceder Proveito ao Fio pertinente;

•  tornar uma Resposta possível;

•  alterar a Posição;

•  permitir uma propriedade de equipamento ou Lavor;

•  transformar uma consequência em outra forma coerente.

Preparar não acumula bônus indefinidamente. Se a situação mudar de maneira que a preparação deixe de fazer sentido, ela deixa de existir ou precisa ser refeita.

### Resposta

Resposta é uma intervenção provocada pela mudança de outra criatura ou pela ocorrência de um evento que afete diretamente a personagem.

Cada personagem possui 1 Resposta por rodada.

Uma Resposta pode:

•  evitar ou reduzir uma consequência;

•  mudar Posição antes que a consequência se complete;

•  proteger outra pessoa ou objeto;

•  interromper uma ação quando a ficção permitir;

•  explorar uma abertura criada pela ação alheia;

•  contra-atacar;

•  preservar Guarda;

•  alterar o alvo de uma intervenção;

•  declarar uma preparação que já havia sido estabelecida.

A Resposta não é uma ação gratuita universal. Ela existe porque algo aconteceu que oferece uma oportunidade legítima de intervir.

Se a Resposta exigir teste, usa o mesmo motor de dois Fios. A existência da Resposta não concede automaticamente sucesso.

#### Limite da Resposta

Uma Resposta só pode reagir ao acontecimento que a acionou. Ela não pode ser usada para iniciar uma segunda sequência independente de ações.

Uma Resposta que provoque uma nova mudança não gera outra Resposta automaticamente no mesmo encadeamento. Cada personagem conserva, no máximo, a sua própria Resposta disponível para a rodada.

Isso impede cadeias infinitas de reação sem transformar a cena em turnos artificiais.

### Relação entre Impulso e Resposta

A distinção fundamental é:

Impulso parte da personagem. Resposta nasce da situação.

Uma personagem pode gastar os dois Impulsos sem gastar sua Resposta. Também pode usar a Resposta cedo na rodada e continuar com seus Impulsos normalmente.

Uma ação que explicitamente consuma 2 Impulsos não pode ser dividida em dois Impulsos diferentes apenas para gerar duas oportunidades independentes. Ela ocupa a rodada porque sua continuidade é parte da ação.

### Ordem de atuação

A ordem de atuação é primariamente ficcional. Iniciativa só entra quando a prioridade realmente estiver em disputa.

No início de um Conflito, o Narrador estabelece uma ordem baseada em quem está em condição de agir primeiro, quem surpreendeu quem e qual Posição cada participante ocupa.

Quando dois ou mais participantes estiverem legitimamente disputando a prioridade, cada um pode rolar Iniciativa pelo motor normal. Uma condição que favoreça ou prejudique essa prioridade aplica Proveito ou Desproveito à rolagem de Iniciativa.

O maior resultado de Enlace estabelece a prioridade. Em empate, a Cadência mais alta decide; persistindo o empate, a ficção resolve ou o Narrador estabelece uma ordem simples sem criar uma segunda camada de desempate.

A ordem pode mudar quando a situação justificar. Uma personagem que perde a Posição pode passar a agir depois; alguém que assumiu controle de uma frente pode agir antes na próxima rodada; uma ameaça que estava distante pode entrar na ordem quando efetivamente se torna participante.

## SEÇÃO 02POSIÇÃO

Posição é a relação atual entre uma personagem, aquilo que ela pretende alcançar e as forças que podem impedir esse alcance.

Ela substitui a necessidade de transformar toda diferença espacial, social ou estratégica em números separados.

Posição responde:

"De onde, em relação a esta situação, eu consigo agir agora?"

### Posição não é apenas distância

Distância pode fazer parte da Posição, mas não a define sozinha. Uma pessoa ao lado de outra pode estar em posição pior se estiver cercada, exposta ou sem autoridade; uma pessoa distante pode estar em posição excelente se possuir cobertura, informação, iniciativa ou controle da passagem necessária.

A Posição pode envolver:

•  distância;

•  cobertura;

•  exposição;

•  acesso;

•  controle de passagem;

•  terreno;

•  apoio;

•  autoridade;

•  informação;

•  prontidão;

•  relação com o objetivo;

•  vulnerabilidade;

•  possibilidade de retirada.

### Estado de Posição

Para manter a leitura rápida, cada participante recebe uma descrição curta de sua Posição em relação à frente relevante do Conflito.

A descrição pode ser:

•  Favorecida ~ a personagem possui acesso ou controle relevante;

•  Disputada ~ nenhum lado possui domínio suficiente para tratar a posição como garantida;

•  Exposta ~ a personagem está em condição em que uma consequência pode alcançá-la com facilidade.

Esses termos não são bônus numéricos universais. Eles são estados de ficção com efeitos definidos pela situação.

Uma Posição Favorecida pode permitir Proveito no Fio pertinente, dispensar um teste quando a posição resolver a barreira ou ampliar o tipo de consequência que a personagem consegue produzir.

Uma Posição Exposta pode permitir que uma ameaça alcance diretamente uma Defesa ou recurso, limitar abordagens ou produzir Desproveito quando a exposição for relevante.

Posição Disputada significa que a oportunidade existe, mas ainda pode ser tomada pelo outro lado.

### Mudança de Posição

Posição deve mudar como consequência de ações, e não como um contador que o Narrador atualiza arbitrariamente.

Uma ação pode:

•  tomar uma posição;

•  perder uma posição;

•  trocar uma posição por outra;

•  proteger uma posição;

•  expor alguém;

•  separar posições;

•  aproximar duas posições;

•  criar uma nova frente de posição.

Uma consequência de deslocamento, derrubada, ameaça social, perda de cobertura ou revelação de informação pode alterar Posição mesmo quando não causa perda de recurso.

### Posição e Guarda

Guarda é a proteção imediata; Posição é a relação mais ampla com a situação.

Uma personagem pode manter Guarda alta e ainda estar em Posição ruim, por exemplo atrás de uma porta que está prestes a ceder. Também pode ter Guarda reduzida e Posição Favorecida, como alguém que chegou ao ponto de controle de uma máquina enquanto está fisicamente exposto.

A alteração de Posição pode modificar Guarda, mas as duas coisas não são automaticamente iguais.

### Posição e Fios

A Posição não altera dados por si só. Ela determina quais abordagens são plausíveis e qual Fio a situação favorece.

Quando uma Posição oferece um método concreto, ela pode gerar Proveito no Tento. Quando uma condição corporal ou exposição altera a capacidade de sustentar a ação, pode afetar o Prumo.

A Posição nunca deve ser usada como justificativa genérica para conceder Proveito em qualquer ação.

### Posição como memória

A principal função da Posição é impedir que o Conflito volte ao zero a cada rolagem.

Se uma personagem tomou a única saída, essa tomada continua existindo. Se perdeu cobertura, a próxima ação começa sem aquela proteção. Se convenceu a testemunha a permanecer, a situação seguinte parte dessa mudança.

O teste altera a Posição; a Posição altera o teste seguinte.

Posição é a memória espacial, social, estratégica ou relacional da cena.

## SEÇÃO 03PRESSÃO

Pressão é a força acumulada que torna a continuidade da situação progressivamente mais difícil de sustentar.

Ela não é sinônimo de dano, Tensão ou urgência.

•  Dano consome Ponto de Vitalidade ou outra continuidade atingida.

•  Tensão desloca o Equilíbrio da personagem ou da malha narrativa.

•  Pressão empurra o Conflito em direção a uma mudança estrutural.

•  Urgência mede quanto tempo ou espaço de oportunidade permanece.

Pressão responde:

"O que está ficando cada vez mais difícil de continuar sustentando?"

### Frente de Pressão

Todo Conflito estruturado possui pelo menos uma Frente de Pressão.

Uma Frente registra:

1.  Fonte ~ quem ou o que produz a pressão;

2.  Objeto ~ o que está sendo pressionado;

3.  Escalada ~ o que acontece quando a pressão aumenta;

4.  Ruptura ~ o que acontece quando aquela continuidade deixa de ser sustentável.

Exemplo:

Fonte: incêndio. Objeto: rota de fuga. Escalada: fumaça ocupa os corredores e reduz as opções. Ruptura: a rota deixa de ser utilizável.

Outro exemplo:

Fonte: conselho da cidade. Objeto: legitimidade da personagem. Escalada: testemunhas se afastam e a audiência se torna pública. Ruptura: a personagem perde o direito de falar em nome do grupo.

A Frente não precisa ser hostil. Uma negociação pode ter como Pressão a aproximação de um prazo, uma relação pode ter como Pressão a necessidade de uma escolha, e uma investigação pode ter como Pressão a destruição progressiva de evidências.

### Escala de Pressão

Quando for útil acompanhar numericamente uma frente, utiliza-se uma escala curta de 0 a 4:

[0922 TABLE]

Pressão | Estado | Leitura

0 | Contida | A frente não ameaça a continuidade imediata

1 | Crescente | A situação restringe opções

2 | Significativa | Continuar exige mudança ou custo perceptível

3 | Crítica | A frente está prestes a romper a continuidade atual

4 | Ruptura | A frente produz sua consequência estrutural

O número só deve existir quando houver vantagem em acompanhá-lo. Uma cena curta pode usar apenas uma descrição de Pressão.

### Como a Pressão aumenta

Pressão pode aumentar quando:

•  uma ação falha e deixa a situação pior;

•  uma consequência é aceita sem resolver sua origem;

•  alguém força um limite;

•  uma oportunidade é perdida;

•  o tempo passa;

•  uma ameaça ganha posição;

•  uma frente é abandonada;

•  uma resposta falha;

•  uma escolha cria uma obrigação que continua ativa.

O Narrador deve indicar por que a Pressão aumentou. O número é consequência da ficção, não punição automática por falhar.

### Reduzir Pressão

Pressão diminui quando a personagem efetivamente resolve, estabiliza ou redireciona a fonte que a produz.

Reduzir Pressão pode exigir:

•  um teste bem-sucedido;

•  mudança de Posição;

•  uso de um Vínculo;

•  gasto de Ponto de Esforço;

•  alteração do objetivo;

•  intervenção sobre a fonte;

•  aceitar outra consequência para aliviar aquela frente.

Um sucesso não reduz Pressão automaticamente. Ele reduz quando a intenção alcançada realmente atua sobre a frente correspondente.

### Pressão em 4

Quando uma Frente chega a 4, ocorre sua Ruptura.

Ruptura não significa necessariamente falha do grupo. Ela significa que aquela forma de continuidade deixou de ser sustentável.

A ruptura pode:

•  fechar uma rota;

•  separar participantes;

•  quebrar uma aliança;

•  iniciar uma perseguição;

•  tornar uma ameaça ativa;

•  impor uma Condição;

•  deslocar a Posição de todos;

•  transformar o objetivo;

•  encerrar o Conflito naquela frente.

Depois da Ruptura, a frente pode desaparecer, ser substituída por outra ou continuar em uma nova forma. Ela não retorna a 0 apenas porque produziu sua consequência.

### Pressão e Testes Prolongados

A Pressão já prevista nos Testes Prolongados passa a usar esta mesma gramática.

Progresso aproxima a personagem do objetivo. Pressão aproxima a situação da ruptura.

Assim, o sistema não precisa de uma segunda mecânica para operações prolongadas.

Um teste bem-sucedido pode gerar Progresso; um resultado com Retorno relevante ou uma consequência adequada pode aumentar Pressão. Uma ação pode produzir os dois ao mesmo tempo.

Exemplo:

A equipe desmonta uma máquina enquanto o prédio desaba. O Enlace concede Progresso na desmontagem. O Retorno revela que a operação consumiu tempo demais, aumentando a Pressão do desabamento.

### Pressão e Tensão

As duas escalas são deliberadamente diferentes.

Tensão representa transformação de Equilíbrio entre Medo e Conhecimento. Pressão representa deterioração ou escalada de uma situação concreta.

Uma cena pode ter Pressão alta e Tensão baixa. Uma discussão íntima pode ter Tensão alta sem qualquer Pressão estrutural mensurável. Uma situação pode produzir ambas, mas uma não substitui a outra.

## SEÇÃO 04CONFLITOS

Conflito é a estrutura de cena usada quando duas ou mais intenções incompatíveis disputam a continuidade de uma situação.

Ele não é sinônimo de combate. Um Conflito pode ser físico, social, investigativo, ambiental, paranormal ou uma perseguição. Essas categorias organizam conteúdo; não criam motores diferentes.

A arquitetura universal é:

objetivo → posição → pressão → ação → consequência → permanência

### Quando iniciar um Conflito

Não se inicia um Conflito apenas porque existe oposição.

A estrutura é necessária quando:

•  as ações de uma parte alteram diretamente as possibilidades da outra;

•  a ordem das intervenções importa;

•  a Posição pode mudar várias vezes;

•  existe uma Frente de Pressão relevante;

•  o resultado precisa permanecer visível entre ações.

Se uma oposição puder ser resolvida por uma única ação significativa, use o motor normal e não transforme a situação em Conflito completo.

### Abertura do Conflito

Ao iniciar um Conflito, o Narrador estabelece:

1.  Objetivos dos participantes relevantes;

2.  O que está em disputa;

3.  Condições de término possíveis;

4.  Posições iniciais;

5.  Frentes de Pressão existentes;

6.  elementos do ambiente que podem ser usados;

7.  ordem ficcional inicial.

O Narrador não precisa declarar todos esses elementos como uma lista para os jogadores. Eles devem estar claros o suficiente para que as escolhas sejam significativas.

### Objetivo

Cada participante relevante possui um objetivo concreto.

"Vencer" é amplo demais. Bons objetivos são:

•  escapar da sala;

•  manter alguém vivo até a chegada de ajuda;

•  impedir a abertura de uma Dobra;

•  fazer o conselho retirar uma acusação;

•  recuperar um Fragmento;

•  atravessar uma ponte antes que ela ceda;

•  descobrir qual das três pessoas está mentindo.

O objetivo define o que conta como Progresso e ajuda a determinar quais consequências realmente importam.

### Ação dentro do Conflito

A personagem declara a intenção de seu Impulso e sua abordagem. O teste usa o motor universal quando existe risco.

O resultado pode alterar:

•  o objetivo;

•  a Posição;

•  a Pressão;

•  uma Defesa;

•  Guarda;

•  um recurso;

•  uma Condição;

•  um Vínculo;

•  equipamento;

•  informação;

•  a possibilidade de outra ação.

Não existe "ataque" como categoria mecânica separada de "manobra" ou "ação social". O motor resolve a intervenção e a consequência define sua forma.

### Permanência

Depois de cada ação relevante, o Narrador atualiza o que mudou na situação: Posição, recursos, Pressão, Condições, acesso ou relações. Esse é o registro imediato do Resto.

Permanência é a continuidade desse Resto para além da cena em que surgiu. Durante o Conflito, a mesa já pode identificar quais mudanças provavelmente atravessarão seu encerramento, sem transformar toda atualização momentânea em Permanência.

O registro imediato pode incluir:

•  nova Posição;

•  Guarda reduzida ou recuperada;

•  Pressão aumentada ou reduzida;

•  Condição criada;

•  recurso perdido;

•  Vínculo alterado;

•  informação descoberta;

•  equipamento danificado;

•  nova oportunidade criada;

•  frente encerrada ou substituída.

Uma ação que não produz efeito nem custo ainda pode ter fracassado de modo significativo, se encerrou uma oportunidade ou revelou um limite. Se nenhuma possibilidade, risco ou informação mudou, reavalie se aquele teste era necessário; não invente uma consequência apenas para preencher o registro.

### A Resposta dentro do Conflito

A Resposta permite que uma personagem intervenha entre Impulsos quando a ação de outra cria uma abertura legítima.

A Resposta pode alterar a resolução, mas não apaga a ação que a provocou. Se duas intervenções forem incompatíveis, resolve-se pela ordem estabelecida pela ficção e, quando necessário, pelo Motor em teste contestado.

Exemplo:

Um adversário tenta tomar a única saída. A personagem usa sua Resposta para alcançar a passagem antes dele. Ambos possuem uma intenção incompatível; cada um forma seu Enlace e o maior prevalece.

### Testes Contestados em Conflitos

Quando dois participantes tentam alterar a mesma coisa em direções incompatíveis, ambos podem realizar o motor.

O maior Enlace prevalece.

Em empate, a condição anterior é preservada, salvo se a ficção ou uma regra específica da disputa estabelecer outro desempate. Ascendente, Retorno e Desvio continuam qualificando o que cada lado conseguiu ou devolveu, mas não criam um segundo motor de desempate.

A comparação não encerra automaticamente o Conflito. Ela resolve apenas a disputa daquela intervenção.

### Múltiplos participantes

Um Conflito pode conter vários participantes com objetivos diferentes.

O Narrador não deve transformar todos em uma fila de ataques. Cada participante escolhe qual frente deseja alterar.

Uma ação pode beneficiar outro participante, abrir uma oportunidade ou mudar a frente que outra pessoa poderá enfrentar.

Isso permite que uma rodada tenha, por exemplo:

uma pessoa segura a ameaça → outra abre a passagem → outra investiga o Fragmento → a ameaça usa sua Resposta para deslocar quem a segura.

A cena continua sendo uma única malha de relações.

### Conflitos físicos

Em um Conflito físico, Posição, Guarda, Defesas, Vitalidade e propriedades das armas ganham maior presença.

Um ataque pode:

•  pressionar Guarda;

•  causar dano;

•  deslocar;

•  derrubar;

•  separar;

•  desarmar;

•  conter;

•  expor;

•  quebrar cobertura;

•  criar oportunidade.

A morte é uma possível consequência extrema, não o estado obrigatório que encerra a cena.

### Conflitos sociais

Em um Conflito social, a disputa pode atingir:

•  confiança;

•  autoridade;

•  acesso;

•  reputação;

•  Vínculos;

•  posição institucional;

•  informação;

•  compromisso;

•  disposição para cooperar.

Ponto de Vitalidade raramente é o eixo principal, mas pode aparecer quando a situação social envolve ameaça física ou coerção corporal.

Uma discussão pode terminar por acordo, retirada, exposição pública, perda de autoridade, mudança de Reputação ou transformação de um Vínculo.

### Conflitos investigativos

Investigação usa Conflito quando o problema está em disputa ativa: alguém tenta esconder evidências, uma instituição bloqueia acesso, um fenômeno se altera enquanto é estudado ou o tempo ameaça destruir uma linha de investigação.

Pistas Fundamentais continuam garantidas. O Conflito decide o que o grupo consegue fazer com elas antes que a situação mude.

Progresso pode representar uma Hipótese consolidada, uma relação compreendida ou uma frente investigativa resolvida. Pressão pode representar evidência destruída, fuga de testemunha, intervenção institucional ou agravamento do fenômeno.

### Conflitos ambientais

O ambiente pode ser tratado como participante quando possui uma dinâmica própria que ameaça os objetivos.

Incêndio, enchente, colapso estrutural, tempestade, contaminação ou instabilidade de uma Dobra podem ter:

•  objetivo ou efeito central;

•  Posição;

•  Frente de Pressão;

•  consequências;

•  condição de ruptura.

Não é necessário transformar o ambiente em "NPC". Basta registrar o que ele está fazendo e como os personagens podem alterar essa dinâmica.

### Perseguições

Perseguição é um Conflito em que a Posição relativa entre perseguido e perseguidor é a frente principal.

Em vez de uma sequência abstrata de testes de velocidade, cada ação deve alterar:

•  distância;

•  rota;

•  cobertura;

•  visibilidade;

•  oportunidade de interceptação;

•  Pressão da perseguição.

Uma perseguição termina quando:

•  o alvo é alcançado;

•  o alvo escapa;

•  uma rota é fechada;

•  alguém abandona a perseguição;

•  surge outro objetivo;

•  uma consequência transforma a situação.

### Conflitos paranormais

Conflitos envolvendo Canalização, Tramas, Fragmentos, Selos ou manifestações anômalas usam a mesma arquitetura.

A diferença está no conteúdo das consequências e nas regras próprias desses elementos.

Uma Trama pode criar uma Posição impossível para uma pessoa comum; um Fragmento pode abrir uma nova frente de Pressão; uma Selagem pode alterar a condição de término do Conflito. O motor continua sendo o mesmo.

### Condições de término

Todo Conflito deve possuir pelo menos uma forma clara de término antes de começar a exigir múltiplas rodadas.

As formas mais comuns são:

•  Ruptura ~ uma continuidade essencial deixa de existir;

•  Contenção ~ a ameaça ou frente é estabilizada;

•  Fuga ~ um participante abandona a disputa;

•  Acordo ~ os objetivos encontram uma solução aceitável;

•  Objetivo alcançado ~ uma parte consegue o que precisava;

•  Transformação ~ a situação muda tanto que aquele Conflito deixa de ser a estrutura adequada.

Um Conflito pode terminar com objetivos diferentes parcialmente alcançados. O mundo não precisa declarar um vencedor único quando a ficção produz um resultado mais interessante.

### Conflito não é combate estendido

A principal função desta arquitetura é fazer com que o Conflito permaneça vivo.

A pergunta de cada rodada não é "quem perdeu mais pontos?". É:

"O que mudou na relação entre os objetivos, as posições e as pressões?"

Quando essa pergunta deixar de produzir mudança, o Conflito deve terminar ou voltar ao modo de resolução normal.

## SEÇÃO 05 ~ EQUILÍBRIO E TENSÃO

Equilíbrio: −10 Medo ← 0 → +10 Conhecimento.

Equilíbrio mede a direção de organização da Malha pessoal entre tendências de Medo e Conhecimento. Não mede moralidade, quantidade de Natureza nem apenas a relação com o desconhecido. Não concede modificador automático.

Tensão: −4 a +4.

Tensão acumula direção. Ao atingir −4, Equilíbrio move −1 e Tensão volta a 0. Ao atingir +4, Equilíbrio move +1 e Tensão volta a 0. Um acontecimento estrutural pode deslocar Equilíbrio diretamente quando não depende de acúmulo.

O eixo possui cinco faixas: Medo prevalente (−10 a −7), Medo inclinado (−6 a −3), Equilíbrio (−2 a +2), Conhecimento inclinado (+3 a +6) e Conhecimento prevalente (+7 a +10).

A faixa não dita comportamento. Ela oferece contexto para que Feição, Lavores, Tramas, Refluxo ou outras regras específicas estabeleçam efeitos próprios, sem virar bônus universal.

Tensão acumula. Equilíbrio desloca. A ficção explica por quê.

### Adquirir e reduzir Tensão

Registre Tensão quando uma manifestação, Refluxo, ruptura ou escolha reiterada pressionar efetivamente a continuidade da pessoa na direção de incorporação e impulso (Medo, negativa) ou de abstração e fixação de padrão (Conhecimento, positiva). Sentir medo, estudar, raciocinar ou agir com frieza não bastam, isoladamente. A mesa identifica o acontecimento e sua direção antes de registrar o deslocamento.

Na ausência de valor escrito no conteúdo, uma ocorrência relevante acrescenta 1 ponto na direção correspondente. Uma ocorrência excepcional pode acrescentar 2 quando sua profundidade tiver sido anunciada e demonstrada. Um mesmo acontecimento não recebe pontos repetidos por cada descrição de seu efeito. Deslocamento direto de Equilíbrio é reservado a transformação estrutural explicitamente estabelecida; não se acumula com Tensão pelo mesmo motivo.

As direções opostas se compensam aritmeticamente: Tensão −2 recebendo +1 passa a −1. Ao atingir ou ultrapassar −4 ou +4, desloque Equilíbrio em um ponto naquela direção e zere Tensão; o excedente não é transportado. Equilíbrio permanece entre −10 e +10. Nova pressão para além de um extremo não cria perda de personagem, Perdição ou bônus automático; qualquer Condição, Marca ou outra transformação precisa ter causa própria declarada.

Recuperar direção exige uma relação concreta capaz de recompor o que se afastou: cuidado corporal, convivência, prática de Ofício, elaboração de uma perda, reconhecimento de limites ou outra ação coerente. Um interlúdio significativo pode produzir 1 ponto de Tensão na direção do centro, sem ultrapassar o centro por esse motivo. Uma cena repetida sem mudança real não multiplica a recuperação. Ancorar e Reassentar não zeram Equilíbrio ou Tensão por conta própria.

Exemplo: uma pessoa está em Equilíbrio −3 e Tensão −2. O uso de um Fragmento exige uma consequência de +1 Tensão, que a leva a −1; esse sinal representa uma pressão diferente, não melhora moral. Mais tarde, com Tensão +3, um trabalho de recomposição concede +1: Equilíbrio vai a −2 e Tensão retorna a 0. A recuperação mudou direção sem apagar os acontecimentos.

### Derivações de cena

Perseguição é Conflito com Posição e Urgência em primeiro plano, usando Pressão quando houver uma frente de deterioração. Não existe teste de perseguição separado.

Viagem e exploração usam Posição, Pressão, Urgência e Preparo conforme a situação. Não existe subsistema de viagem obrigatório.

Rodada é unidade de atenção. Impulso parte da personagem; Resposta nasce da situação.

## A Cena como Malha situada

Uma Cena não é apenas um intervalo dramático. É o conjunto de posições, urgências, relações e frentes de pressão que dão sentido às ações presentes. Por isso, o mesmo objeto pode ter efeitos distintos em cenas diferentes: uma lanterna em sala iluminada é ferramenta comum; num arquivo sem luz, torna-se condição de acesso; diante de uma manifestação que reage à observação, pode se tornar um risco.

Ritmo recomendado: anuncie objetivo e risco, descreva duas ou três relações decisivas, dê lugar às intenções, resolva apenas as incertezas que realmente mudam algo e atualize a situação. Uma Cena prolongada precisa ganhar novas perguntas, não repetir a mesma DT com diferentes palavras.

### A Pressão tem causa

[1152 TABLE]

Faixa | Leitura narrativa | Pergunta operacional

0 | Continuidade preservada | Que situação existe sem agravamento?

1 | Primeiro sinal de deslocamento | O que começou a falhar ou reagir?

2 | Consequência perceptível | Que possibilidade ficou mais estreita?

3 | Iminência de Ruptura | Que escolha urgente ainda existe?

4 | Ruptura da frente | Que estado foi alterado e que nova cena se abriu?

Esses nomes são auxílio de leitura, não condições adicionais. O nível 4 produz a Ruptura da frente declarada, não a morte universal ou o encerramento automático de todo conflito. Reduzir Pressão requer intervenção plausível; ignorá-la não impede que seus gatilhos atuem.

Exemplo — o depósito. A cada intervenção demorada sob uma estrutura instável, uma causa identificável pode elevar a Frente de Pressão: vibração de máquina, aproximação de guardas, falha de escora ou deterioração de um Selo. O Narrador não sobe o relógio porque alguém falou por muito tempo, mas porque algo que havia sido preparado como risco realmente aconteceu. Se chegar a 4, a contenção local cede. O grupo pode ainda preservar pessoas e informações, embora a situação já seja outra.

## Protocolo de conflito físico, alvo defensivo e Resposta

Um ataque deve declarar um objetivo principal — ferir, deslocar, conter, desarmar, quebrar Guarda ou outro efeito admissível — e uma abordagem. A mesa identifica o limiar principal que essa mudança enfrenta. Em um mesmo ataque, não se exige rolar contra Guarda e depois contra Resistência/Evasão apenas para conseguir atingir o corpo.

•  Guarda protege contra agressão imediata enquanto existe postura, cobertura ou instrumento defensivo apto. Evasão protege uma saída ou deslocamento do efeito quando não se está efetivamente usando Guarda. Resistência protege a sustentação física de um estado ou corpo contra força já incidente. A escolha do limiar é ditada pelo efeito, não pelo maior valor disponível.

•  Lucidez protege interpretação e coerência cognitiva; Firmeza protege vontade, identidade e relações. O mesmo total inicial não torna seus gatilhos intercambiáveis.

•  Uma Resposta é anunciada antes de se concluir a consequência que pretende alterar. Ela pode, conforme a Posição, proteger outro alvo, criar cobertura, converter um ataque em teste contestado, mudar o limiar admissível ou reduzir uma consequência; não concede uma segunda Defesa grátis após o ataque atingir o limiar.

•  Cada participante tem no máximo uma Resposta por rodada. A própria Resposta não dispara reação em cadeia; quem já gastou a sua não pode responder novamente sem regra extraordinária específica.

•  Guarda quebrada é um estado concreto. Se uma intervenção bem-sucedida rompe a cobertura/postura que lhe dava suporte, registre exatamente o que se perdeu; não remova arbitrariamente o valor-base de Cadência da ficha.

Cobertura e proteção situacional — padrão operacional: cobertura parcial ou escudo efetivamente interposto confere +1 à Guarda atual; cobertura dominante e estável pode conferir +2. A contribuição total combinada dessas fontes ordinárias limita-se a +2, sem acúmulo infinito. Cobertura total que impossibilite a linha de ataque não concede +2: impede aquela abordagem até que se crie acesso. Posição Exposta remove o benefício concedido por proteção perdida; não reduz automaticamente a Guarda-base.

### Dano-base e escala de efeitos

A arma possui um valor-base entre 1 e 3 PV e uma ou mais propriedades narrativas, sem bônus universal ao Enlace. Esta tabela é a normalização operacional de equipamento comum; armas singulares e Tramas especificam o próprio efeito.

[1165 TABLE]

Exemplo de equipamento | Dano-base quando ferir é a consequência principal | Observação de uso

Improviso leve / pequeno instrumento | 1 PV | Exige acesso plausível e pode causar exposição

Lâmina leve, bastão ou arma curta | 1 PV | Pode favorecer precisão, ocultação ou controle

Lâmina longa, arma de uma mão de impacto, projétil comum | 2 PV | Uso condicionado ao manejo e à distância

Arma pesada ou dispositivo de alta pressão preparado | 3 PV | Exige condições de manejo, recarga, preparo ou exposição

Manobra sem intenção de ferir | 0 PV | Produz deslocamento, contenção, desarme ou mudança de Guarda, se atingir o limiar

Consequência principal por Impulso: por padrão, uma intervenção de 1 Impulso seleciona um efeito principal. Uma margem elevada (+4 ou mais), Consonância bem-sucedida, propriedade expressa ou Costura legítima pode adicionar uma extensão qualitativa diretamente ligada ao efeito; não converte automaticamente cada elemento do vetor em dano, Condição, quebra de Guarda e Pressão ao mesmo tempo. A fonte da extensão deve ser nomeada. Extensões extraordinárias múltiplas exigem uma autorização textual específica, custo, risco ou operação mais complexa.

Ataques contra personagem a 0 PV: usam o protocolo de Incapacitação, Morte e Colapso deste livro. Não se registra PV negativo.

Exemplo: um agressor com Ímpeto d8 e Luta d6 busca ferir alguém com Guarda 11; rola 6 e 5. Enlace 11: alcança. O alvo recebe o dano-base da arma e a posição se altera apenas se isso já estiver autorizado pela arma, margem ou ficção. Se o alvo tinha cobertura efetiva de +1, sua Guarda seria 12, e essa mesma tentativa não o alcançaria; uma Resposta válida anunciada antes poderia mudar a configuração do confronto.

PARTE V
