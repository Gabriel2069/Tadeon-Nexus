---
title: "TdV II · Expressão"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "EXPRESSÃO", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# EXPRESSÃO

EQUIPAMENTO, LAVORES, TRAMAS, SELAGEM E CANALIZAÇÃO

Uma prática encontra a forma concreta de sua expressão.

Como uma intervenção concreta ganha forma no mundo.

## SEÇÃO 01ARMAS E EXPRESSÃO DA VIOLÊNCIA

Armas são instrumentos de intervenção. O ataque continua sendo resolvido pelo motor comum; a arma define o que a personagem consegue fazer com o alcance daquele ataque e que tipo de consequência ele pode produzir.

O princípio central é:

Uma arma não existe para aumentar dano; existe para tornar certas formas de alterar a situação possíveis.

### Estrutura de uma arma

Toda arma relevante pode ser descrita por seis elementos:

•  Família ~ contato, distância, improvisada ou outra classificação útil para reconhecer acesso e prática de manejo. Não existe reserva separada de proficiências: a competência é tratada por Alinhavos e permissão ficcional.

•  Alcance ~ a distância em que a arma consegue operar sem perder sua função.

•  Manejo ~ mãos, postura, espaço ou condição física necessários para utilizá-la.

•  Impacto ~ expressão de dano e/ou efeito físico produzido quando o ataque alcança o alvo.

•  Propriedades ~ aquilo que torna aquela arma diferente de outra que causaria impacto semelhante.

•  Porte e acesso ~ como o objeto é transportado, que mãos ou suportes ocupa e em quais circunstâncias pode ser alcançado. Esse campo substitui Espaço de Carga como número isolado.

A arma não possui um teste próprio. O teste continua sendo Matriz + Alinhavo, escolhidos pela abordagem. Uma mesma arma pode ser operada de maneiras diferentes, mudando Fios e consequências conforme o que a personagem realmente faz.

### Carga, armadura e equipamento comum

Carga é tratada pela capacidade de transportar e acessar o equipamento na situação, sem a fórmula de Espaços da edição antiga. Registre objetos volumosos, mãos ocupadas e suportes que importam. Se o conjunto impede uma abordagem, ela exige reorganização, ajuda ou abandono de parte da carga. Quando apenas a dificulta sob risco, aplique Desproveito ao Fio efetivamente comprometido. Não se cobram simultaneamente uma penalidade abstrata de carga e outra pelo mesmo impedimento.

Armadura não acrescenta Redução de Dano universal. Sua descrição informa a agressão que consegue deter, as partes protegidas e as limitações de manejo. Uma proteção pode impedir uma abordagem inadequada, modificar a consequência ou contribuir com Guarda, quando for efetivamente interposta. Se conceder bônus ordinário de Guarda, integra o teto combinado de +2 das proteções situacionais. Redução numérica de dano só existe quando expressamente descrita no equipamento.

Ferramentas, kits, mecanismos e veículos seguem o mesmo critério: registre função, acesso, limite, manutenção e efeito que realmente alteram escolhas. Um kit adequado pode permitir cuidado ou reparo; possuir o kit não concede automaticamente Proveito em toda aplicação do Ofício.

### Propriedades

Propriedades são efeitos funcionais, não uma coleção de bônus pequenos. Uma propriedade deve responder a pelo menos uma destas perguntas:

•  Que posição ela altera?

•  Que defesa ou proteção ela contorna?

•  Que consequência ela produz além de ferir?

•  Que abertura ela cria para outra pessoa?

•  Que tipo de alvo ela consegue afetar?

•  Que condição do ambiente ela aproveita?

Propriedades recorrentes podem incluir:

Demolidora ~ produz ou amplia destruição de estruturas, cobertura ou objetos.

Desarmante ~ pode retirar um objeto da posse do alvo quando a situação comportar esse resultado.

Separadora ~ cria distância, divide pessoas ou interrompe uma formação.

Contensora ~ prende, imobiliza ou limita deslocamento.

Empurradora ~ desloca o alvo em vez de apenas feri-lo.

Expositora ~ revela ou cria abertura para outro personagem explorar.

Silenciosa ~ permite agir sem produzir o tipo normal de ruído da arma.

Pressurizada ~ converte uma ação ou carga preparada em efeito adicional especificado pela arma.

A lista é aberta. Novas propriedades devem ser definidas como verbos de intervenção, não como bônus universais.

### Dano

O dano continua existindo como uma forma de consequência sobre o Ponto de Vitalidade. Porém, o dano não substitui a leitura de Ascendente, Retorno e Desvio.

Um ataque bem-sucedido pode, conforme a abordagem e a propriedade da arma:

•  causar dano;

•  deslocar;

•  derrubar;

•  desarmar;

•  separar;

•  conter;

•  quebrar cobertura;

•  criar exposição;

•  impor Condição;

•  pressionar Guarda ou Posição;

•  abrir uma oportunidade para outro personagem.

Quando mais de uma consequência fizer sentido, o resultado não precisa ser dividido artificialmente em "ataque" e "efeito": o Enlace resolve a ação e a leitura do resultado determina a forma da expressão.

### Consonância com armas

Consonância não produz automaticamente dano dobrado. Quando um ataque alcança a DT/Defesa e também apresenta Consonância, a arma pode expressar seu melhor uso: ampliar alcance, intensificar sua propriedade, preservar posição, criar uma segunda abertura ou elevar a consequência conforme a descrição da arma.

Armas podem possuir uma propriedade específica de Consonância, mas não existe um multiplicador universal de dano.

### Integridade de equipamento

Quando um objeto tem história suficiente para que seu desgaste importe, ele possui Integridade. Integridade não é recurso da personagem. É estado do objeto.

Ela pode ser reduzida quando o equipamento:

•  intercepta um impacto excepcional;

•  é usado além de seu limite;

•  sofre uma consequência apropriada;

•  entra em contato com fenômeno que afeta sua estrutura;

•  perde a função que sustentava sua utilidade.

Reparar a matéria não restaura automaticamente a função narrativa ou a Assinatura de um objeto alterado.

Integridade de equipamento é descrita, por padrão, como condição funcional: apto, danificado ou inutilizado, acompanhada da função comprometida e do reparo necessário. Um impacto só muda esse estado quando a consequência foi plausivelmente produzida. Não se subtrai dano de PV de uma Integridade que não possui escala numérica. Objetos singulares podem declarar uma escala própria, com máximo, fontes de perda e efeito do esgotamento.

O dano-base ordinário de uma arma comum é de 1 a 3 PV, conforme a propriedade do equipamento e a intenção alcançada. Dano permanece uma forma de consequência física, não outro motor.

### Lavores

Lavor é a capacidade especial incorporada pela personagem. Seu papel é abrir uma possibilidade que o motor básico, sozinho, não oferece.

Um Lavor deve preferencialmente mudar o que a personagem pode fazer, quando pode fazê-lo, como pode expressá-lo ou qual consequência consegue produzir. Lavor não deve existir apenas para conceder +1, +2 ou uma rolagem melhor de maneira genérica.

Todo Lavor é escrito com seis elementos:

1.  Nome ~ a forma curta usada na mesa.

2.  Vertente ~ a prática ou práticas com as quais ele se relaciona.

3.  Gatilho ~ quando o Lavor pode ser acionado.

4.  Gesto ~ o que a personagem faz para colocá-lo em funcionamento; pode consumir Impulso, Resposta, tempo ou nenhuma unidade adicional quando o gesto fizer parte da ação normal.

5.  Expressão ~ a nova possibilidade produzida.

6.  Preço/limite ~ Ponto de Esforço, frequência, condição, exposição ou outra restrição quando necessária.

#### Regra de custo

O Lavor não cria uma economia paralela. Se exigir recurso, usa principalmente Ponto de Esforço. Se o preço for ficcional, usa consequência, condição, posição, equipamento, Vínculo ou outro elemento já existente.

Um Lavor pode também alterar diretamente um ponto do motor, mas precisa declarar a extensão da alteração. Exemplos legítimos:

•  alterar qual Fio pode receber Proveito;

•  permitir determinada abordagem que normalmente seria impossível;

•  converter uma consequência em outra forma coerente;

•  modificar alcance ou alvo de uma ação;

•  usar uma Resposta de maneira incomum;

•  produzir uma propriedade de arma ou equipamento;

•  interagir com Tramas, Fragmentos ou Selos.

#### Lavores e testes

Um Lavor nunca substitui automaticamente o motor quando existe risco significativo. Ele pode:

•  tornar o teste desnecessário quando a capacidade realmente resolve a situação;

•  modificar o teste existente;

•  criar uma opção que antes não existia;

•  mudar a consequência possível de um resultado.

Se um Lavor disser que uma situação rotineira é automaticamente resolvida, isso é autoridade de ficção, não um bônus escondido.

#### Lavor completo ~ Segurar a Passagem

Vertente: Corpórea e Cinética. Gatilho: alguém alcançável é deslocado através de uma passagem que a personagem ocupa e consegue fisicamente sustentar. Gesto: gastar a Resposta da rodada e 1 PE para interpor corpo, apoio ou ferramenta. Expressão: transferir para si o alvo do deslocamento e disputar sua manutenção de Posição pelo Motor, quando houver oposição ativa. Preço/limite: exige apoio real e passagem ao alcance; não impede destruição de escala superior àquilo que o suporte comporta.

Resolva a oposição uma única vez: a personagem usa Matriz e Alinhavo pertinentes à sustentação, contra os Fios da intervenção que provoca o deslocamento. Se prevalecer, preserva a passagem; se falhar, recebe o deslocamento e suas consequências anunciadas. O Lavor não concede Guarda extra nem cancela dano que não tenha sido redirecionado. Aquisição comum: 4 PU com incorporação plausível. Exemplo: depois de incorporar este Lavor, Tomas gasta sua Resposta e 1 PE para assumir a força que arrancaria Iria do vão; a disputa resolve quem conserva a Posição, sem um segundo teste gratuito de defesa.

### Transcendentes

Lavor Transcendente é uma forma especial de Lavor que nasce de transformação irreversível. Ele não é adquirido simplesmente por acumular pontos ou repetir uma ação.

Preserva-se a estrutura já existente:

•  Marco ~ o acontecimento que tornou o Lavor possível;

•  Capacidade ~ o que passou a existir;

•  Preço ~ o que a transformação exige;

•  Sinal ~ como a mudança permanece visível na personagem ou no mundo.

Um Transcendente pode possuir qualquer Vertente, inclusive mais de uma.

Neste capítulo, “um Transcendente” abrevia Lavor Transcendente. Na Urdidura, Transcendente pode designar a pessoa ou Malha transformada. A transformação pertence à continuidade do ser; o Lavor registra uma capacidade que dela resulta. Um caso não concede automaticamente todo o repertório do outro.

### Vertentes

Vertente é uma linguagem de prática, não uma classe, atributo ou caminho obrigatório. Ela serve para organizar Lavores segundo a natureza do que eles transformam.

As quatro Vertentes-base são preservadas como organização do repertório:

#### Corpórea

Lavores que trabalham diretamente com corpo, resistência, força, matéria, presença física, armas de contato ou transformação corporal.

#### Cônscia

Lavores que trabalham com percepção, memória, leitura, atenção, emoção, interpretação e organização interna.

#### Cinética

Lavores que trabalham com deslocamento, timing, postura, trajetória, espaço, objetos em movimento e aproveitamento de posição.

#### Canalizada

Lavores que trabalham diretamente com Urdidura, Canalização, Tramas, Fragmentos, Selagem e outras formas de expressão além do funcionamento ordinário.

Um Lavor pode pertencer a mais de uma Vertente quando sua prática realmente cruza essas linguagens. A segunda Vertente não concede bônus: ela registra a relação do Lavor com outra parte da prática.

### Malha

A Malha é o conjunto vivo das Vertentes e Lavores de uma personagem. Ela não é apenas um índice de ficha. Ela descreve como as práticas da pessoa se apoiam, se atravessam e podem formar soluções que um Lavor isolado não ofereceria.

A Malha possui três funções:

Repertório ~ registra todas as possibilidades incorporadas pela personagem.

Ligação ~ permite identificar quando dois Lavores pertencem a práticas relacionadas e podem ser usados na mesma abordagem.

Costura ~ permite criar uma expressão híbrida quando dois Lavores compatíveis, de Vertentes diferentes, participam da mesma ação.

#### Costura de Malha

Quando dois ou mais Lavores de Vertentes diferentes podem atuar sobre a mesma intenção e cada um possui um Gatilho válido, a personagem pode Costurar a Malha.

A Costura de Malha não é uma ferramenta de combinação rotineira. Ela serve para momentos específicos em que duas práticas realmente dependem uma da outra para produzir uma expressão que nenhuma produziria sozinha.

Para Costurar:

1.  declare a intenção única;

2.  diga o que cada Lavor contribui;

3.  aplique normalmente os custos, condições e limites de ambos os Lavores;

4.  faça um único teste pelo motor, salvo se um dos Lavores exigir explicitamente uma ação separada;

5.  o resultado expressa a combinação, e não uma soma de bônus.

Em geral, os dois Lavores cobram seu próprio preço e a própria combinação pode criar risco adicional, especialmente quando suas expressões exigem continuidades difíceis de sustentar ao mesmo tempo. O jogador não deve tratar Costura como um “combo” recorrente para otimizar resultados: se a relação entre os Lavores não for necessária naquele momento, não há Costura mecânica.

A Costura pode:

•  ampliar uma possibilidade;

•  mudar a forma da consequência;

•  permitir que uma propriedade de um Lavor modifique outro;

•  produzir uma solução que nenhum dos dois ofereceria isoladamente.

A Costura não aumenta automaticamente Enlace, Ascendente ou dados. Ela aumenta complexidade de expressão. Quando a combinação ultrapassar a escala normal de um dos Lavores, o custo apropriado é pago ou uma nova DT/condição é estabelecida pela situação.

Isso faz da Malha uma mecânica de composição sem transformá-la em árvore de classes.

### Relação com Ponto de Urdume

A aquisição de Lavores continua integrada ao sistema de Desenvolvimento e Ponto de Urdume. Os custos canônicos desta edição são os definidos no capítulo de Desenvolvimento: o gasto concorre diretamente com todas as demais possibilidades de incorporação.

A regra de design é que comprar um Lavor deve representar incorporação de prática: estudo, treinamento, convivência, sobrevivência, descoberta, transformação ou experiência coerente com a Feição.

Lavores, Vertentes e Malha obedecem à economia de PU e aos limites da Costura.

## Expressões diferentes, arquitetura idêntica

Ações ordinárias e extraordinárias não precisam aparentar o mesmo acontecimento. Uma queda, uma promessa, uma operação de Canalização e um Selo possuem condições diferentes. Ainda assim, cada uma pode ser lida por uma estrutura comum: que continuidade sustenta o fenômeno, qual intervenção tenta alterá-la, que oposição existe, qual expressão emerge e o que permanece.

Isso não elimina as cinco fases da Canalização, os procedimentos próprios de Selagem ou os custos particulares de Lavores. Ao contrário: explica por que cada um se especializa sem criar outro Motor.

### Quadro comparativo de expressão

[1525 TABLE]

Sistema | Relação tocada | Como entra na mesa | Limite que permanece

Equipamento | Corpo, ferramenta, Posição e ambiente | Torna abordagem possível; dano/propriedade definida | Não substitui prática nem permite efeitos ilimitados

Lavor | Aprendizado e padrão de prática pessoal | Especializa uma intervenção ou consequência | Custo, gatilho e trajetória de desenvolvimento

Trama | Relações da Tessitura alcançadas por Canalização | Aproximação, Puxagem, Tecitura, Expressão, Relaxamento | Intensidade, custo, Resistência e Refluxo

Fragmento | Padrão persistente deixado por Dobra, com suporte e atividade próprios | Atividade própria e propriedades descritas | Procedência, Integridade e condições de uso

Selagem | Dependência estrutural de uma manifestação | Diagnóstico, acesso, Tecitura e Fixação | Ponto de Costura, manutenção e pressão

### A diferença entre representar e explicar

Na ficha, um Lavor pode aparecer como escolha que distingue uma personagem. No mundo, ele é a expressão recorrente de uma prática incorporada. Na ficção, sua execução pode ser extraordinária ou discreta. Tratar esses três níveis como um só gera erro: conhecer um nome não compra uma capacidade; usar uma descrição poética não dispensa custos; tocar uma estrutura cosmológica não prova que a personagem compreendeu seu fundamento.

## SEÇÃO 02SELAGEM

Selagem é o procedimento pelo qual uma Dobra, Furo, manifestação ou relação instável recebe uma continuidade suficientemente estruturada para deixar de depender apenas do instante da intervenção.

Selagem não é "lançar uma magia de fechar". Ela é uma operação sobre a Costura que mantém o fenômeno existindo daquela maneira.

A estrutura fechada é:

Diagnóstico → Acesso → Tecitura → Fixação → registro do Resto e da Permanência

Diagnóstico descobre o que sustenta o problema. Acesso torna possível alcançar a dependência identificada. Tecitura constrói a resposta. Fixação liga a resposta a uma continuidade que sobreviva à operação. O registro final distingue o resultado imediato e aquilo que permanecerá depois da cena.

### Ponto de Costura

O Ponto de Costura é a relação específica que permite à Dobra continuar existindo daquela maneira.

Não existe uma lista universal de Costuras.

Uma Dobra pode depender de:

memória; significância; linguagem; objeto; rotina; promessa; posição; ausência; sequência; Vínculo; segredo; contradição; arquitetura; instituição; ou outra relação que a ficção estabeleça..

As lentes "Memória, Significância, Linguagem e Alma" podem orientar diagnóstico, mas não constituem uma taxonomia obrigatória.

### Diagnóstico

Antes da Tecitura, o grupo precisa determinar, na medida necessária:

1.  Estágio ~ em que grau a Dobra ou Furo está;

2.  Natureza ~ que relação profunda está sendo tocada;

3.  Domínio ~ que aspecto dessa relação está em jogo, quando aplicável;

4.  Assinatura ~ como aquela manifestação se expressa;

5.  Tensão ~ que força direcional mantém a situação ativa;

6.  Território ~ onde a relação se manifesta;

7.  Pontos de Costura ~ quais relações precisam ser alteradas para que a Selagem permaneça.

O diagnóstico não precisa descobrir toda a cosmologia. Ele precisa descobrir o suficiente para que a resposta possa ser sustentada.

### Descoberta do Ponto de Costura

O Narrador deve apresentar manifestações e pistas suficientes para que os jogadores possam inferir a Costura.

A pergunta central é:

"O que precisa continuar verdadeiro para isso continuar existindo assim?"

Cada Costura essencial não resolvida deve aumentar a dificuldade ou impedir que a Selagem seja considerada definitiva, conforme a gravidade do caso.

A antiga referência de +3 por Costura essencial não resolvida não é regra da v2.0. Costuras não resolvidas podem aumentar a exigência, impedir a Fixação ou produzir consequência por meio do Motor e da ficção, conforme o que estiver em jogo. Não existe modificador universal de +3.

### Acesso

Nem toda Costura pode ser tocada diretamente.

Uma investigação de Selagem pode revelar que o grupo precisa:

•  obter acesso a um arquivo;

•  convencer uma testemunha;

•  alterar uma rotina;

•  recuperar um objeto;

•  reparar uma estrutura;

•  restaurar um Vínculo;

•  interromper uma sequência;

•  criar uma nova relação capaz de substituir a antiga.

Assim, Selagem pode naturalmente gerar uma cadeia de investigação e Conflitos sem criar subsistemas paralelos.

### Tecitura do Selo

A Tecitura é uma Canalização orientada para produzir um Selo.

O líder realiza a resolução principal usando o motor de dois Fios. Outros personagens podem contribuir quando sua participação modifica materialmente a operação.

A contribuição pode assumir:

•  Engenharia;

•  Ciências;

•  Ofício;

•  Investigação;

•  Canalização;

•  Persuasão ou Diplomacia;

•  proteção;

•  ritual;

•  manutenção;

•  ação determinada pelo diagnóstico.

O Alinhavo Selagem representa a prática específica de diagnosticar, compor e fixar Selos. Ele é a escolha direta quando essa é a abordagem. Outros Alinhavos podem resolver contribuições próprias ou a intervenção principal quando o diagnóstico demonstrar como aquela prática alcança e reorganiza a Costura. Uma ferramenta ou desenho comum não confere, por si, acesso à Tecitura profunda.

### Costura como condição de Tecitura

Um Selo não precisa destruir a Dobra. Ele precisa modificar a relação que a sustenta.

Se o grupo apenas bloquear a manifestação enquanto a Costura permanece intacta, o resultado pode ser:

•  contenção temporária;

•  redução de expressão;

•  deslocamento da manifestação;

•  retorno posterior;

•  transformação do fenômeno em outra forma.

A Selagem definitiva exige que a resposta esteja ligada à Costura relevante.

### Fixação

A Fixação conecta o Selo a uma continuidade capaz de sobreviver ao momento da operação.

Exemplos:

•  arquitetura;

•  prática repetida;

•  calendário;

•  comunidade;

•  objeto;

•  registro;

•  manutenção;

•  Vínculo;

•  outra Trama estável;

•  relação criada durante a própria intervenção.

Um símbolo isolado não sustenta uma borda apenas porque foi desenhado corretamente.

### Resto e Permanência

Depois da Fixação, o Narrador deve registrar:

•  o que foi encerrado;

•  o que permanece ativo;

•  que relação agora sustenta o Selo;

•  qual custo ficou para trás;

•  que consequência foi criada;

•  que manutenção existe;

•  o que acontece se a Fixação for removida.

O registro distingue o efeito imediato do Selo e as continuidades que atravessarão a cena. Uma Selagem não apaga a história que tornou sua intervenção necessária.

### Cargas

Cargas de Selagem representam componentes, preparação, esforço logístico e relações necessárias para executar a operação.

Cargas podem ser:

•  consumidas;

•  preservadas;

•  danificadas;

•  substituídas;

•  recuperadas por procedimento.

Não existe quantidade universal de Cargas por estágio. Cada Selagem define as Cargas concretas necessárias como parte de seu conteúdo. Sua função é representar componentes, preparação, esforço logístico e relações necessárias.

### Pressão e Pulsos

Selagem pode ocorrer sob Pressão normal de cena. Não é necessário criar uma barra paralela.

Quando um fenômeno produz Pulsos, eles representam mudanças episódicas na manifestação ou na continuidade que exigem resposta. Um Pulso pode:

•  avançar o Compasso de Urgência;

•  alterar Posição;

•  danificar uma Carga;

•  expor o grupo;

•  ativar um Fragmento;

•  alterar a expressão da Dobra;

•  criar uma nova consequência.

Pulsos não são automaticamente "dano".

### Estágios de Selagem

Os nomes de referência para a profundidade de uma operação são:

•  Pré-Furo;

•  Furo I;

•  Furo II;

•  Furo III;

•  Âncora I;

•  Âncora II;

•  Âncora III;

•  Zona de Aspecto.

Essa sequência organiza referências de preparação; não é uma escada cosmológica obrigatória. Prega/Pré-Furo indicam alteração inicial, Bolsão/Furo indicam passagem, Ancoragem/Âncora indicam fixação e Zona de Aspecto indica territorialização. Revérbero é estabilização e pode exigir apenas manutenção. Os graus I–III qualificam profundidade dentro de cada forma sem obrigar toda Dobra a percorrer todos os graus.

As antigas referências de DT 16, 18, 20, 22, 24, 26, 28 e 30 e os antigos custos de Cargas pertencem ao histórico. Na v2.0, Selagem usa o Motor e a Defesa ou oposição pertinente quando houver resistência; sua profundidade é determinada pelo estágio cosmológico e pela cadeia de Costuras. Não existe escada universal de DT nem quantidade universal de Cargas por estágio; cada Selagem define suas Cargas concretas como conteúdo.

### Falha, alcance e resultado parcial

Uma falha de Tecitura não precisa destruir o Selo nem invalidar o diagnóstico.

O resultado pode ser:

•  Selo incompleto;

•  contenção temporária;

•  Fixação instável;

•  Refluxo da Trama utilizada;

•  aumento de Pressão;

•  alteração de uma Costura;

•  exposição do grupo;

•  abertura de uma nova frente.

O Narrador deve preferir consequências que deixem a situação mais definida, não simplesmente "não funcionou".

### Selagem e Fragmentos

Um Fragmento pode servir como:

•  suporte de Assinatura;

•  componente de Fixação;

•  fonte de informação;

•  meio de reconhecer a Costura;

•  condutor de uma Trama;

•  componente descartável;

•  risco de interferência.

O Fragmento nunca transforma automaticamente uma Selagem em sucesso. Ele altera o que é possível ou o preço da operação conforme sua própria condição.

### Selagem e Vínculos

Vínculos são especialmente relevantes porque uma Selagem pode depender de uma continuidade social real.

Um Vínculo pode:

•  fornecer acesso;

•  servir de testemunho;

•  sustentar uma prática;

•  manter uma Fixação;

•  ser ameaçado pela operação;

•  tornar-se parte da nova Costura.

Se a Selagem exigir um Vínculo, esse Vínculo não pode ser tratado como mero bônus. A relação precisa efetivamente carregar parte da continuidade.

### Manutenção

Algumas Selagens são capazes de permanecer sem manutenção. Outras precisam de uma relação que continue sendo exercida.

Quando a manutenção é relevante, defina:

•  quem mantém;

•  o que precisa ser feito;

•  com que frequência;

•  o que muda quando falha;

•  qual relação torna a manutenção possível.

Manutenção não deve existir apenas para cobrar tarefas. Ela deve representar a razão pela qual a nova continuidade continua de pé.

### Regra de encerramento

Uma Selagem é considerada concluída quando o grupo consegue responder:

1.  o que mantinha a manifestação;

2.  o que o Selo alterou;

3.  onde a nova continuidade está fixada;

4.  qual consequência permanece.

Se essas quatro respostas existirem na ficção, não é necessário prolongar a operação por testes adicionais apenas para "terminar o procedimento".

## SEÇÃO 03CANALIZAÇÃO / URDIDURA INTEGRADA

Canalização é o sistema que traduz diretamente a relação entre a personagem e a Urdidura. Ela não é magia genérica, não é geração de energia e não é uma coleção de efeitos pré-formatados.

A definição canônica permanece:

Canalizar é aproximar-se de uma malha primordial, puxar Fios, organizá-los e pedir ao Reflexo que incorpore temporariamente uma relação que não teria surgido daquele modo.

A Trama é o padrão costurado. A Expressão é a resposta observável do Reflexo. O Relaxamento devolve os Fios à continuidade possível. O Refluxo é a forma desorganizada como uma Trama retorna quando sua relação não se sustenta.

Os cinco movimentos são obrigatórios conceitualmente, mas não precisam consumir cinco ações:

Aproximação → Tração → Tecitura → Expressão → Relaxamento

Uma personagem experiente pode percorrer os cinco em um único Impulso quando a ficção permitir. Uma operação perigosa pode transformar um ou mais movimentos em etapas separadas.

### Aproximação

Aproximação cria acesso à Natureza escolhida.

Ela não exige necessariamente um Furo. O canalizador cria uma inclinação temporária entre sua própria continuidade e a relação que deseja tocar.

Aproximação responde:

•  a que relação estou me aproximando?

•  por que consigo percebê-la?

•  o que no ambiente, instrumento, Fragmento ou preparação oferece acesso?

•  o que pode me alcançar antes que eu consiga tecer?

Instrumentos, Fragmentos, gestos e ritos podem oferecer forma à Aproximação, mas não substituem compreensão.

### Puxagem

Puxagem é a tensão produzida ao deslocar Fios de sua disposição.

Ela não é o teste de Canalização.

Isso preserva uma distinção fundamental:

Puxagem mede o quanto a aproximação e a tração pressionam a continuidade do canalizador; Canalização mede se a Trama consegue ser organizada.

Os dois riscos podem produzir resultados diferentes.

É possível:

•  suportar a Puxagem e falhar a Tecitura;

•  sofrer uma consequência da Puxagem e ainda tecer;

•  tecer parcialmente e sofrer Refluxo;

•  falhar nos dois.

No sistema atual, a resistência à Puxagem deve ser resolvida pela Constituição e pelo recurso apropriado, sobretudo Ponto de Inteireza, sem reintroduzir Temperança como Alinhavo.

#### Resolver a Puxagem

Antes da Tecitura, declare se o acesso é seguro, se cobra um custo inevitável ou se existe um risco distinto de perder continuidade. Acesso seguro não exige teste adicional. Custo inevitável em PI, quando escrito na Trama ou estabelecido pela situação, é informado e pago antes da tentativa; se não puder ser pago, essa abordagem não começa. Custo não é perda automática por toda Canalização.

Se uma presença ativa pressiona o canalizador, ela usa seus dois Fios contra Lucidez, Firmeza ou a Defesa pertinente. Uma resposta ativa incompatível pode converter a intervenção em disputa pelo protocolo comum. Se o risco depende de uma ação própria do canalizador, separável da Tecitura, resolva essa ação pelo Motor contra o limiar anunciado. Nesse caso, registre o que suportar a pressão permite e qual consequência a falha produz antes de continuar.

Quando Puxagem e Tecitura pertencem ao mesmo gesto e não há um acontecimento independente a resolver, faça um único teste. O limiar decide a Expressão; o risco de Puxagem é uma consequência possível previamente declarada, interpretada com a margem e os Fios sem custo obrigatório por Retorno baixo. Uma consequência de Puxagem já aplicada não é cobrada novamente como Refluxo pelo mesmo deslocamento. Dois testes só são necessários quando existem duas ações ou oposições efetivamente distintas, e não porque o processo possui dois nomes.

### Intensidade

As três intensidades preservadas são:

•  Repuxo ~ intervenção superficial sobre uma relação acessível;

•  Tração ~ deslocamento mais profundo de relações conectadas;

•  Estiramento ~ intervenção que força relações espessas, profundas ou altamente interdependentes.

Intensidade não significa simplesmente "mais dano, área ou alcance". Ela representa profundidade da relação tocada.

Uma Trama de Estiramento pode afetar uma única pessoa e ainda ser muito mais perigosa que uma Trama de Repuxo que alcança várias pessoas superficialmente.

Tração possui dois usos contextuais. Como movimento, é o deslocamento de Fios presente no processo de Canalização; como Intensidade, é a categoria intermediária entre Repuxo e Estiramento. Percorrer o movimento de Tração não transforma toda Trama em uma Trama de intensidade Tração. Puxagem nomeia a pressão sofrida durante esse acesso e deslocamento.

### Tecitura

Tecitura é a organização dos Fios deslocados em um padrão reconhecível.

É aqui que nasce a Trama.

Quando Tecitura exige teste, usa o motor comum:

Fio de Prumo + Fio de Tento → Enlace → Desvio → Consonância.

O Fio de Prumo deve representar a Matriz pela qual o canalizador sustenta a intervenção.

O Fio de Tento deve representar o Alinhavo que dá forma prática à intervenção.

O Alinhavo Canalização é a prática explícita de perceber, aproximar, tracionar e tecer Fios. Outros Alinhavos podem participar quando a Trama depende de uma prática diferente ou complementar.

### Expressão

Expressão é o modo como o Reflexo acomoda a Trama.

O resultado visível não é a própria Trama. Duas Tramas podem produzir fogo e possuir Naturezas, Assinaturas, custos e comportamentos completamente diferentes.

A Expressão deve responder ao padrão tecido, ao alvo, à Intensidade e à situação.

Quando houver Consonância com alcance, a Expressão pode adquirir uma forma excepcionalmente coerente com a intenção e a Assinatura, sem converter o crítico em multiplicador universal de dano.

### Relaxamento

Relaxamento é a etapa de retorno dos Fios à continuidade possível.

Uma Trama bem sustentada pode retornar sem consequência relevante.

Uma Trama forçada pode deixar:

•  Refluxo;

•  alteração de Assinatura;

•  exposição;

•  Condição;

•  perda de Ponto de Inteireza;

•  desgaste de Fragmento;

•  mudança de Posição;

•  outra consequência coerente.

Relaxamento não é "limpar o efeito". Ele determina o que fica depois que o canalizador solta os Fios.

### Trama

Cada Trama relevante deve possuir:

•  Alvo;

•  Intensidade;

•  Alcance;

•  Duração;

•  Resistência;

•  Custo em Ponto de Esforço;

•  Refluxo;

•  Assinatura.

A Trama não é uma ficha de feitiço que substitui a ficção. Esses campos descrevem a relação que será criada e como ela poderá continuar ou terminar.

### Custo

O custo de Canalização deve ser distribuído entre três coisas diferentes:

1.  Ponto de Esforço ~ esforço controlável da operação;

2.  Ponto de Inteireza ~ quando a própria continuidade do canalizador é pressionada;

3.  consequência ficcional ~ quando a Trama modifica uma relação que naturalmente deixa preço.

Nenhum deles deve ser usado apenas como "mana". O custo deve representar a forma como a intervenção exige continuidade da personagem.

Os custos de Canalização seguem o procedimento canônico: PE cobre esforço controlável; PI é comprometida quando a própria continuidade é tocada; consequências ficcionais entram quando a relação exige preço. Não existe tarifa universal separada do conteúdo da Trama. Cada Trama declara seu custo quando exigir recurso; na ausência de custo declarado, a intervenção não consome PE apenas por ser Canalização.

### Sustentação

Sustentar uma Trama é continuar oferecendo continuidade ao padrão depois da Tecitura.

Se uma Trama exige sustentação, o custo deve ser explícito e utilizar Ponto de Esforço quando apropriado.

A sustentação pode terminar porque:

•  o canalizador decide relaxar;

•  o custo deixa de ser pago;

•  a condição da Trama deixa de existir;

•  a Trama sofre interferência;

•  o objetivo foi alcançado;

•  o padrão se torna autossustentado por uma nova Fixação.

Uma Trama sustentada não deve exigir "um novo teste por rodada" sem uma mudança real na situação.

### Resistência de Trama

Quando o alvo puder resistir à expressão, a resistência usa a Defesa apropriada da Constituição ou da situação.

Não existe uma "resistência à magia" universal separada.

A defesa deve corresponder ao que a Trama está tentando alterar:

•  corpo e impacto → Resistência;

•  evasão física/posição → Evasão ou Guarda, quando pertinente;

•  mente, percepção ou coerência → Lucidez;

•  vontade, identidade ou sustentação relacional → Firmeza;

•  situação externa → oposição ficcional, Posição ou Conflito.

Isso mantém Canalização integrada ao restante do sistema.

### Refluxo

Refluxo não é Puxagem.

Puxagem é a pressão sofrida durante a aproximação e tração.

Refluxo é a forma específica como uma Trama mal sustentada ou rompida retorna ao sistema.

O Refluxo depende de:

•  Trama;

•  Natureza;

•  Domínio, quando aplicável;

•  Assinatura;

•  ambiente;

•  margem e forma da falha;

•  relação tocada.

Não existe uma tabela universal de Refluxo.

Um Refluxo pode produzir dano, Condição, alteração de posição, alteração de memória, mudança ambiental, Pressão, perda de recurso, marcação de Assinatura ou outra consequência coerente.

### Proveito e Desproveito na Canalização

Proveito e Desproveito continuam funcionando sobre um dos dois Fios.

•  instrumento, método, preparação ou conhecimento técnico tendem a afetar Tento;

•  estado físico, estabilidade, integridade ou condição pessoal tendem a afetar Prumo.

A fonte deve justificar qual Fio muda.

Não se soma um bônus mágico adicional à Canalização apenas por possuir um Fragmento, Lavor ou instrumento.

### Forçar

Forçar permite elevar um Fio antes da rolagem mediante custo.

Em Canalização, Forçar pode representar puxar além da margem segura, insistir em uma Trama difícil ou usar um suporte de modo agressivo.

O custo segue a regra universal de Forçar: 1 PE por avanço até d12 e 2 PE para d12→d20; com PE em 0, vale a modalidade de uma vez por cena mediante consequência ficcional equivalente.

Forçar não garante sucesso. Ele altera a capacidade disponível e pode tornar o resultado mais consequente se a operação continuar incompatível com a situação.

### Trama completa ~ Fio de Escuta

Assinatura: Conhecimento ~ Linguagem ~ vibração que conserva uma voz. Alvo: uma superfície contínua previamente tocada, como cano, grade ou painel. Intensidade: Repuxo. Alcance: o canalizador permanece em contato com a mesma estrutura e escuta uma fonte sonora no mesmo recinto ou em um recinto contíguo, desde que ela faça a estrutura vibrar; não atravessa descontinuidades materiais nem recupera fala já encerrada. Duração: até o fim da cena, enquanto houver contato. Custo: 1 PE para iniciar; nenhum custo adicional de sustentação. Gesto: 1 Impulso para estabelecer a relação; escutar depois integra a observação ordinária.

Resolução: Nexo + Canalização quando houver vibração concorrente, pressão ou ocultação relevante. Para o exemplo, DT 10 representa separar a voz de uma máquina próxima; sem dificuldade real, a aproximação adequada funciona sem teste. Não há Puxagem independente em acesso seguro. Resistência: uma presença que altere ativamente a comunicação oferece oposição pelo Motor; parede sem consciência não recebe Lucidez. A Trama não produz por si tradução de língua desconhecida nem informação que nunca percorreu a superfície.

Refluxo declarado: uma falha pode tornar audível a própria voz do canalizador no ponto de escuta, expondo sua presença. Falha severa pode deixar uma repetição intrusiva como Condição, com saída por afastamento da estrutura e recomposição em segurança. Só haverá perda de PI se a manifestação efetivamente comprometer a continuidade e esse risco tiver sido anunciado.

Uso: em uma etapa posterior de sua trajetória, Iria já possui Nexo 3 (d10), Canalização 2 (d8) e aprendeu esta Trama. Ela toca o cano de um depósito, paga 1 PE e obtém Prumo 6 e Tento 4. Enlace 10 alcança a DT: a conversa torna-se audível, sem outra consequência automática. A Consonância 5+5 também alcançaria a DT e poderia separar uma segunda voz entre as vibrações. Em 4+4, a coerência sem alcance não resolve a escuta: a máquina encobre a fala e o Refluxo pode denunciar a tentativa. Em 1+1, aplica-se também Matriz Abalada.

### Canalização e Lavores

Um Lavor pode:

•  permitir uma aproximação que normalmente seria impossível;

•  mudar qual Fio recebe Proveito;

•  alterar o modo de Expressão;

•  mudar alvo, alcance ou duração;

•  transformar uma consequência;

•  permitir uma Resposta incomum;

•  usar um Fragmento de forma específica;

•  criar uma Costura de práticas.

O Lavor não substitui a Trama. Ele modifica como aquela pessoa é capaz de canalizar.

### Canalização e Fragmentos

Fragmentos são suportes de continuidade incompleta.

Eles podem:

•  facilitar Aproximação;

•  fornecer Assinatura;

•  armazenar uma preparação;

•  conduzir uma Trama;

•  produzir atividade espontânea;

•  impor uma expressão;

•  responder a gatilhos;

•  limitar ou distorcer a Canalização.

A ficha de Fragmento deve registrar apenas o que é relevante para seu uso, preservando como campos centrais:

•  Assinatura;

•  Integridade;

•  Tramas compatíveis;

•  Condição;

•  Procedência.

Informações adicionais podem ser acrescentadas quando o Fragmento exigir.

### Fragmentos ~ conter, usar e conservar

Um Fragmento é um padrão persistente de uma Dobra incompletamente desfeita. Seu suporte pode ser objeto, matéria orgânica, som, inscrição ou outra forma; não é necessariamente uma anomalia material transportável. Sua ficha registra Assinatura, Procedência, Condição, Integridade, Tramas compatíveis, limite de uso e contenção necessária. Se o padrão não puder ser deslocado sem perder continuidade, não se presume que caiba num inventário.

Condição informa se a borda está contida, exposta ou em outra configuração específica. Um Fragmento contido pode conservar atividade compatível com seu Selo; contenção não equivale a inocuidade. Integridade informa quanto de seu padrão ainda conserva função. Por padrão é qualitativa: registre a função preservada, a limitação produzida e o que pode romper o padrão. Uma escala numérica só é utilizada quando a ficha fornece máximo, perdas, restauração e resultado em zero; não se importa automaticamente a escala de equipamento ou das antigas Categorias.

Identificação começa pelos sinais acessíveis. Um teste pertinente pode revelar Assinatura, Gatilhos, limite ou condição de contenção, conforme o método. Uma informação indispensável à continuidade da investigação segue a regra de Pista Fundamental. Examinar um Fragmento não revela automaticamente toda a sua história nem concede uma Trama nova.

Usar dentro do limite declarado não consome Integridade por presunção. Forçá-lo além do limite exige anunciar a função que será comprometida e a consequência antes da tentativa; sem permissão ficcional, o uso é impossível. Se houver escala numérica, aplique a perda expressa. Esgotar Integridade encerra a função extraordinária sustentada por aquele padrão e aciona somente o desfecho descrito: dispersão, inatividade, ruptura ou outra consequência. O suporte físico pode sobreviver sem conservar o Fragmento.

Conter ou Selar um Fragmento usa Diagnóstico, Acesso, Tecitura e Fixação. Defina a borda que pode sustentá-lo, os componentes e o risco de interferência. A operação não adquire a DT ou o custo de um Furo apenas por ambos serem manifestações. Restaurar o suporte não recompõe automaticamente a Assinatura; a restauração do padrão requer a relação descrita na ficha ou descoberta em investigação. Dispersão deliberada também exige acesso à dependência que o mantém e um desfecho anunciado.

#### Fragmento completo ~ Vidro da Última Janela

Suporte: lâmina de vidro amarelado transportável em caixa opaca. Procedência: uma janela preservada depois da pacificação de uma Dobra de Memória. Assinatura: Conhecimento ~ Memória ~ testemunho sem sucessor. Condição inicial: contido por moldura inscrita que conserva a identificação da janela. Integridade inicial: padrão preservado, com uma única perspectiva acessível. Não possui pontos de Integridade.

Gatilho e limite: ao ser exposto à luz e sustentado diante de uma cena, o vidro conserva por instantes detalhes que seu observador deixou de notar. Uso compatível: pode sustentar uma Trama de observação ou memória, oferecendo Proveito no Tento quando a perspectiva for pertinente, dentro do limite de um deslocamento líquido. Não revela o que ninguém poderia ter visto nem substitui o aprendizado da Trama. Seu auxílio não altera automaticamente custo de PE ou DT.

Forçar: tentar obter outra perspectiva compromete o padrão; declare antes do uso que o vidro deixará de distinguir rostos e que uma presença ausente poderá fixar-se no reflexo. Um segundo uso além do limite esgota sua função: resta vidro comum, e a presença somente se manifesta se essa consequência já tiver sido anunciada. Restauração antes do esgotamento exige identificar e reintegrar o testemunho que a moldura conserva, por investigação e Selagem adequada. Depois da dispersão, não se presume recuperável o mesmo Fragmento.

Uso: quando já tiver aprendido a Trama apropriada, Tomas examina um registro e o vidro íntegro. O auxílio ao método eleva Tento de d6 a d8; seus demais custos permanecem os da Trama. Ao encerrar a observação, o vidro mantém sua Integridade porque foi usado dentro do limite. Abrir a caixa, exibi-lo e investigá-lo depois continuam decisões com consequências próprias, não despesas automáticas.

### Canalização e Selagem

Selagem é uma aplicação especializada da Canalização.

A diferença é o objetivo:

•  Canalização produz ou altera temporariamente uma relação;

•  Selagem procura criar uma continuidade capaz de manter uma alteração depois da intervenção.

Por isso, uma Selagem usa a sequência própria:

Diagnóstico → Acesso → Tecitura → Fixação → registro do Resto e da Permanência.

Uma Trama comum não deve apagar automaticamente um Selo estabelecido.

Para desfazer uma Selagem, a ficção precisa alcançar a continuidade que a sustenta ou produzir uma intervenção de peso comparável.

### Canalização em Conflitos

Quando Canalização ocorre dentro de um Conflito, ela usa a mesma estrutura:

Objetivo → Posição → Pressão → Ação → Consequência → Permanência.

Uma Trama pode:

•  alterar Posição;

•  criar ou reduzir Pressão;

•  impor uma Condição;

•  modificar Guarda;

•  atingir um Vínculo;

•  abrir acesso;

•  conter uma Ameaça;

•  criar uma oportunidade;

•  modificar o próprio objetivo.

O Narrador não deve resolver a cena apenas por "dano mágico".

### Escala da intervenção

A escala de uma Trama é determinada pela relação tocada, não por uma lista universal de círculos.

A pergunta principal é:

"Quantas relações precisam se reorganizar para que esta Expressão exista?"

Uma intervenção que toca uma única pessoa pode ter escala profunda. Uma intervenção ampla pode ser superficial.

A Magnitude das Ameaças não é automaticamente a Intensidade de uma Trama. São escalas diferentes.

### Encerramento

Uma Canalização termina quando:

•  a Expressão cumpriu seu objetivo;

•  o canalizador Relaxa;

•  a sustentação termina;

•  a Trama é rompida;

•  o alvo a neutraliza;

•  a Trama se transforma em nova continuidade;

•  ou a consequência torna outra resolução necessária.

Depois do encerramento, sempre que relevante, registre o que permaneceu.

### Expressão e criação

AÇÃO├── intenção├── intervenção└── expressão    ├── corpo / abordagem    ├── equipamento    ├── Lavor    ├── Malha    ├── Trama    ├── Canalização    └── Selagem

Equipamento, crafting, Lavores, Tramas, Canalização e Selagem não possuem um motor próprio: especificam possibilidades, procedimentos, custos ou consequências que voltam ao núcleo quando há incerteza.

Criar algo é uma Ação de criação que pode combinar Ofício, Preparo e Expressão. O resultado produz uma continuidade concreta para ações posteriores.

PARTE VII
