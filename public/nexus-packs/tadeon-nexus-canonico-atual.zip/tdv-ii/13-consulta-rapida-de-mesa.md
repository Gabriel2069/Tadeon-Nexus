---
title: "TdV II · Consulta rápida de mesa"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "CONSULTA RÁPIDA DE MESA", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# CONSULTA RÁPIDA DE MESA

Referência de leitura e consulta para a mesa.

## APÊNDICE B.1Teste universal

Intenção → abordagem → Matriz (Prumo) + Alinhavo (Tento) → modificadores de Fio → Forçar, se declarado → rolagem → Falha Crítica (1,1), se ocorrer → Enlace versus DT → Consonância → consequência principal → Resto.

[2645 TABLE]

Elemento | Regra operacional

Prumo | Resultado do dado da Matriz

Tento | Resultado do dado do Alinhavo

Enlace | Prumo + Tento; alcança se ≥ DT

Ascendente | Maior dos dois resultados

Retorno | Menor dos dois resultados

Desvio | Prumo − Tento, com direção positiva/negativa

Consonância | Resultados idênticos; sucesso crítico só se Enlace alcança DT e não é (1,1)

Falha Crítica | Prumo = 1 e Tento = 1; Matriz Abalada (Desproveito no Prumo) até fim da cena

Proveito / Desproveito | Até um deslocamento líquido por Fio após cancelamentos

Forçar | Antes da rolagem; 1 PE para avanço ordinário, 2 PE d12→d20 autorizado; 1 Fio e 1 vez por teste

Teste contestado | Enlace maior prevalece; empate preserva situação anterior

## APÊNDICE B.2DTs e margens

[2647 TABLE]

DT | Leitura de dificuldade

8 | Rotineira sob risco

10 | Desafio treinado

12 | Importante

14 | Alto

16 | Excepcional

18 | Raro

20 | Limite humano

24 | Transcendente baixo

28 | Transcendente alto

32+ | Transcendente máximo

[2648 TABLE]

Margem: Enlace − DT | Classificação

+0 a +3 | Êxito

+4 a +7 | Êxito elevado

+8 ou mais | Êxito excepcional

−1 a −2 | Quase

−3 a −5 | Falha com consequência

−6 ou menos | Falha severa

A classificação pela margem não depende da DT: o limiar determina a dificuldade; a diferença em relação ao limiar descreve a intensidade do resultado.

## APÊNDICE B.3Recursos, economia e desenvolvimento

[2651 TABLE]

Regra | Valor

PV máximo | 6 + 2 × Ímpeto

PI máximo | 6 + Nexo + Lastro

PE máximo | 5 + Nexo + Lastro

Resistência | 6 + 2 × Ímpeto

Evasão / Guarda-base | 6 + 2 × Cadência

Lucidez / Firmeza | 6 + Nexo + Lastro

Impulsos | 2 por rodada; não acumulam

Respostas | 1 por rodada; provocada por evento

Pressão | 0 a 4; 4 = Ruptura da frente

Equilíbrio | −10 a +10

Tensão | −4 a +4; ao atingir limite, Equilíbrio desloca 1 e Tensão retorna a 0

Desenvolvimento | 0–100% em 20 Marcos de 5%

Ponto de Urdume | 2 PU por Marco, 40 PU totais

Matriz | d4 → d6: 3 PU; d6 → d8: 4; d8 → d10: 5; d10 → d12: 6; d12 → d20: 7 + incorporação transcendente

Alinhavo | +1 categoria: 2 PU, até d12 ordinário

Lavor comum / amplo | 4 / 6 PU

Ampliação extraordinária | 3–7 PU, segundo alcance e incorporação

## APÊNDICE B.4Recuperação e estados críticos

[2653 TABLE]

Condição | Resultado

Pausa breve | PE +2; PI +1; PV +0, ou +2 com cuidado

Repouso profundo | PE ao máximo; PI +3; PV +5 com cuidado ou +2 sem

Recuperação plena | PE e PV ao máximo; PI somente após reconstrução da continuidade

PV = 0 | Incapacitada; nova consequência física relevante provoca À Beira

À Beira | Estabilizar antes da janela declarada; senão Morte

PI = 0 | Colapso, Condição Crítica e transformação duradoura da Feição

PE = 0 | Sem custeio de ações extraordinárias; Forçar a 0 PE é exceção uma vez por cena

Âncora após Ancorar | Abalada até Reassentar por ação significativa

## APÊNDICE B.5Preparação rápida de encontro

Descreva o objetivo, a Posição inicial, a Frente de Pressão, o limiar ou oposição, os estados lembrados, a dependência ou limite da Ameaça e as condições alternativas de término. Use ficha completa só quando a presença e a recorrência realmente necessitarem.

APÊNDICE C
