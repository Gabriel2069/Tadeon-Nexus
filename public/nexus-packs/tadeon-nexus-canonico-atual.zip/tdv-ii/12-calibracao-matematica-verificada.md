---
title: "TdV II · Calibração matemática verificada"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "CALIBRAÇÃO MATEMÁTICA VERIFICADA", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# CALIBRAÇÃO MATEMÁTICA VERIFICADA

Referência de leitura e consulta para a mesa.

Este apêndice substitui as percentagens incorretas presentes no antigo relatório de simulações. Não modifica os resultados possíveis do Motor; recalcula sua distribuição.

## APÊNDICE A.1Método, hipóteses e convenções

Dois Fios independentes e uniformes, com faces de 1 até o valor máximo, produzem Enlace = Prumo + Tento. Para dados dA + dB, a probabilidade exata de alcançar DT T é a contagem de pares ordenados (p,t) em que p+t >= T, dividida por A×B. Não se presumem Proveito, Desproveito, Forçar, Guarda contextual, Costura ou Consonância adicional. Um resultado igual à DT é sucesso.

A chance de Consonância é min(A,B)/(A×B) = 1/max(A,B). Falha Crítica por dupla unidade (1,1) ocorre com probabilidade 1/(A×B) por teste; ela é subconjunto das Consonâncias, mas prevalece como Falha Crítica e não concede êxito. Os valores de êxito das tabelas seguintes assumem DT ≥ 8, de modo que essa precedência não altera suas percentagens.

## APÊNDICE A.2Probabilidades exatas ~ Enlace contra DT

Escala ordinária ~ DT 8 a 18

[2608 TABLE]

Fios | DT 8 | DT 10 | DT 12 | DT 14 | DT 16 | DT 18

d4 + d4 | 6,25% | 0,00% | 0,00% | 0,00% | 0,00% | 0,00%

d6 + d6 | 41,67% | 16,67% | 2,78% | 0,00% | 0,00% | 0,00%

d8 + d6 | 56,25% | 31,25% | 12,50% | 2,08% | 0,00% | 0,00%

d10 + d8 | 73,75% | 55,00% | 35,00% | 18,75% | 7,50% | 1,25%

d12 + d12 | 85,42% | 75,00% | 61,81% | 45,83% | 31,25% | 19,44%

d12 + d20 | 91,25% | 85,00% | 77,08% | 67,50% | 57,50% | 47,50%

d20 + d20 | 94,75% | 91,00% | 86,25% | 80,50% | 73,75% | 66,00%

Escala elevada e transcendente ~ DT 20 a 32

[2610 TABLE]

Fios | DT 20 | DT 24 | DT 28 | DT 32

d4 + d4 | 0,00% | 0,00% | 0,00% | 0,00%

d6 + d6 | 0,00% | 0,00% | 0,00% | 0,00%

d8 + d6 | 0,00% | 0,00% | 0,00% | 0,00%

d10 + d8 | 0,00% | 0,00% | 0,00% | 0,00%

d12 + d12 | 10,42% | 0,69% | 0,00% | 0,00%

d12 + d20 | 37,50% | 18,75% | 6,25% | 0,42%

d20 + d20 | 57,25% | 38,25% | 22,75% | 11,25%

As percentagens são arredondadas a duas casas apenas na apresentação; todos os cálculos são realizados por enumeração exata dos resultados.

## APÊNDICE A.3Recorte de competências iniciais

As Matrizes 2, 3, 3, 2 correspondem a d8, d10, d10, d8. O recorte abaixo seleciona dois Alinhavos d8 e dois dos quatro Alinhavos d6 da criação, formando 16 pareamentos hipotéticos. Os outros dois d6 e os quinze Alinhavos d4 ficam fora deste recorte; a tabela não representa a média geral da ficha nem a frequência real das ações.

[2614 TABLE]

DT | Média entre 16 combinações | d10 + d8 (especialidade inicial)

8 | 65,55% | 73,75%

10 | 43,75% | 55,00%

12 | 23,98% | 35,00%

14 | 10,05% | 18,75%

16 | 2,68% | 7,50%

18 | 0,31% | 1,25%

20 | 0,00% | 0,00%

24 | 0,00% | 0,00%

28 | 0,00% | 0,00%

32 | 0,00% | 0,00%

Essa média descreve um conjunto matemático de pareamentos hipotéticos, não a frequência de ações de um jogador real. Uma campanha que privilegie competências favoritas e DTs acessíveis terá distribuição própria. O relatório antigo registrava 34,38%, 11,46%, 1,56% e 0% para DT 8/10/12/14+, sem correspondência com Enlace = Prumo + Tento sob essas hipóteses; os valores ficam formalmente revogados nesta edição.

Se o mesmo cálculo abranger os seis Alinhavos treinados da criação (dois d8 e quatro d6), as 24 combinações com as quatro Matrizes produzem 63,91% em DT 8; 41,88% em DT 10; 22,24% em DT 12; 8,72% em DT 14; 2,07% em DT 16; e 0,21% em DT 18. Acima disso, o máximo inicial de d10+d8 não alcança o limiar sem modificações. O recorte descreve acesso matemático sob hipóteses explícitas, não desempenho observado.

## APÊNDICE A.4Consequências para dificuldade e encontro

•  DT 8 é um desafio razoável sob risco, não uma exigência que deva falhar duas vezes em cada três para um personagem bem treinado.

•  DT 10 é significativa para competências comuns e acessível para especialidades iniciais.

•  DT 12 e DT 14 representam obstáculos progressivamente sérios para personagens iniciais, mas não são inalcançáveis em d10+d8.

•  DT 16 a 20 põem à prova especialização e grandes aberturas. Um especialista d12+d12 já pode obter DT 20, ainda que raramente.

•  DT 24 é o máximo teórico de d12+d12 e é alcançável apenas em seu resultado máximo ordinário; acima de 24, são necessários meios extraordinários. Por isso, a denominação “transcendente” na tabela de DTs significa escala narrativa, não impossibilidade matemática absoluta para qualquer caso.

•  Um confronto d10+d8 contra limiar 12 tem 35% de êxito direto, antes de equipamentos e Respostas. A faixa de acertos de 3%–25% mencionada no relatório antigo depende de pareamentos particulares e não pode ser enunciada como faixa universal de combate.

## APÊNDICE A.5Distribuição de Enlace, Retorno, Desvio e Consonância

[2625 TABLE]

Fios | Enlace médio | Retorno médio | Desvio absoluto médio | Consonância | Dupla unidade

d4 + d4 | 5,00 | 1,88 | 1,25 | 25,00% | 6,25%

d6 + d6 | 7,00 | 2,53 | 1,94 | 16,67% | 2,78%

d8 + d6 | 8,00 | 2,77 | 2,46 | 12,50% | 2,08%

d10 + d8 | 10,00 | 3,45 | 3,10 | 10,00% | 1,25%

d12 + d12 | 13,00 | 4,51 | 3,97 | 8,33% | 0,69%

d12 + d20 | 17,00 | 5,31 | 6,38 | 5,00% | 0,42%

d20 + d20 | 21,00 | 7,18 | 6,65 | 5,00% | 0,25%

Interpretação: dados com média de Enlace igual podem ter Retorno e Desvio distintos. A probabilidade de Consonância depende do maior número de faces; ela não cresce com o aumento bruto da potência do personagem, o que preserva sua natureza excepcional.

Consonância total não equivale à chance de crítico: o crítico exige vencer o limiar ou a disputa e exclui (1,1). Contra DT 12, d10+d8 tem 35% de êxito e 3,75% de crítico; d12+d8 tem 45,83% de êxito e 3,125% de crítico. Elevar um Fio pode aumentar alcance e diminuir coincidências bem-sucedidas. Essa propriedade pertence ao Motor, não é erro de cálculo nem garante que uma personagem mais capaz critique com maior frequência.

## APÊNDICE A.6Faixa de dano e escalas de recurso

O dano-base de equipamento comum 1 a 3 PV preserva a importância de PV iniciais na faixa próxima a 10–12 e permite derrotas tanto por dano quanto por Posição, Guarda, Condição ou mudança de objetivo. Esse equilíbrio depende da chance de atingir o limiar e do número de intervenções possíveis; não prova, sozinho, equilíbrio de todos os encontros. O Narrador avalia as três dimensões das Ameaças: capacidade de oposição, pressão de continuidade e complexidade de resolução.

## APÊNDICE A.7Limites da validação matemática

As tabelas demonstram consistência aritmética do Motor e invalidam apenas afirmações incompatíveis com ele. Não substituem playtests reais de decisão, duração de cenas, economia de PE, frequência de Respostas, ritmo de Marcos ou percepção de justiça. Ajustes de conteúdo continuarão sendo registrados por errata explícita, sem criar um segundo motor.

## APÊNDICE A.8Leitura visual das probabilidades

A curva não define a natureza da dificuldade por si. A DT representa um limiar na presença das condições declaradas. Um arquivista competente sem acesso ao arquivo não substitui permissão ficcional por uma rolagem extraordinária. Um personagem com capacidade baixa, mas com uma abordagem plausível e tempo suficiente, pode resolver ações sem teste. Os números modelam a incerteza; não recriam o mundo a partir de sorte.

A curva também demonstra por que uma diferença de duas unidades na DT pode alterar substancialmente a frequência de sucesso. Para manter o encontro justo e compreensível, o Narrador deve declarar o que está em jogo e deixar claro quando a preparação altera Posição, acesso ou o Fio propriamente dito.

APÊNDICE B
