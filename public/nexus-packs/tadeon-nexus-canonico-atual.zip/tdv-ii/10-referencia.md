---
title: "TdV II · Referência"
node_type: "rule"
summary: "Procedimentos da edição TdV II v2.0; fonte normativa fornecida por Tadeu."
status: "canonical"
visibility: "workspace"
tags: ["tdv-ii", "v2.0", "fonte-primaria"]
properties: {"rules_version": 2, "source_document": "02_Livro_de_Regras(3).docx", "source_sha256": "8846b485dc528e3998de9227a033bea746eb439d6519ea7f3362a7a8f9515c0f", "source_part": "REFERÊNCIA", "text_extraction": true}
---
> Revisão mecânica: [[tdv-ii/00-fundacao-mecanica-viii|Fundação VIII]] prevalece nos pontos reformados; esta página conserva o texto anterior para referência.


> Fonte: [[00-fontes/tdv-ii-v2|Livro de Regras TdV II v2.0]].

# REFERÊNCIA

VOCABULÁRIO E INTEGRIDADE

O vocabulário preserva diferenças que a mesa precisa reconhecer.

Os termos e princípios estáveis da v2.0.

## SEÇÃO 01VOCABULÁRIO CONSOLIDADO DO TDV II

Os termos abaixo formam o vocabulário estável da v2.0. As decisões de terminologia estão concentradas neste vocabulário e no Apêndice C. Isso não altera a função das mecânicas já consolidadas.

[2528 TABLE]

Conceito | Termo TdV II

Bloco de identidade | Feição

Capacidades amplas | Matrizes

Corpo/potência | Ímpeto

Agilidade/coordenação | Cadência

Cognição/percepção | Nexo

Social/vontade/identidade | Lastro

Perícia | Alinhavo

Ordem de atuação | Iniciativa

Dado da Matriz | Fio de Prumo

Dado do Alinhavo | Fio de Tento

Maior dado | Ascendente

Menor dado | Retorno

Soma dos dois | Enlace

Diferença/direção | Desvio

Coincidência dos dois resultados; crítico apenas com alcance | Consonância

Vantagem | Proveito

Desvantagem | Desproveito

Habilidade | Lavor

Grupo de Lavores | Vertente

Conjunto das Vertentes | Malha

Pontos de Vida / PV | Ponto de Vitalidade

Sanidade / PS | Ponto de Inteireza

Pontos de Esforço / PE | Ponto de Esforço

PM | Ponto de Urdume

Uso de uma Âncora | Ancorar

Identidade geral | Feição

Unidade de participação em cena | Impulso

Reação | Resposta

Conjunto de cenas com oposição | Conflito

Defesa física | Guarda

Desenvolvimento | Desenvolvimento

Posição no mundo | Reconhecimento

Pergunta investigativa | Pergunta Central

Informação essencial | Pista Fundamental

Rede de relações investigadas | Teia

Explicação provisória | Hipótese

Evidência incompatível | Contradição

Relógio investigativo | Compasso de Urgência

Relação que sustenta uma Dobra | Ponto de Costura

Fechamento de continuidade | Selagem

Resposta desorganizada de uma Trama | Refluxo

Pressão da aproximação dos Fios | Puxagem

Presença mínima | Figurante

Presença recorrente compacta | Adversário

Presença estrutural | Ameaça

Escala de presença | Magnitude

Combinação funcional de capacidades | Costura

Padrão operacional de uma Ameaça | Modo de agir

## SEÇÃO 02PRINCÍPIOS QUE NÃO DEVEM SER VIOLADOS

1.  Dois Fios continuam sendo a resolução comum.

2.  Matriz e Alinhavo continuam sendo componentes diferentes e ambos importam.

3.  Enlace resolve acesso à DT.

4.  Ascendente e Retorno qualificam como a ação aconteceu.

5.  Desvio possui direção.

6.  Consonância é extraordinária, não um segundo sucesso comum.

7.  Alinhavos não têm famílias mecânicas. Iniciativa integra a lista por sua função ativa de disputar prioridade; não cria uma família nem uma competência defensiva paralela.

8.  Feição tem seis pilares, não sete.

9.  PA não retorna como contador com outro nome.

10.  Âncora é qualidade de algo que já existe na Feição, não novo campo.

11.  Vínculo é relação com história, não bônus social genérico.

12.  Ancorar não apaga consequência; reduz ou redireciona seu modo de atravessar a pessoa.

13.  Marca possui Gatilho, Manifestação e Resíduo; não é penalidade passiva nem contador.

14.  Equilíbrio e Tensão preservam suas escalas atuais.

15.  A nomenclatura da Urdidura não deve ser alterada sem necessidade real.

16.  Canalização não será redesenhada apenas para encaixar o novo motor.

17.  Investigação continua exigindo competência mecânica e raciocínio do jogador.

18.  Nenhuma simplificação pode retirar abrangência funcional da ficha.

19.  As probabilidades do Apêndice A foram verificadas por enumeração exata. Os valores normativos de recursos, danos, custos e progressão são parâmetros desta edição, sujeitos a evidência de mesa; não se presume que a correção aritmética demonstre seu balanceamento completo.

20.  Lavor cria possibilidade; não existe apenas para empilhar bônus.

21.  Vertente não é classe, trilha obrigatória ou fonte de bônus.

22.  Malha pode Costurar práticas, mas não soma bônus automaticamente.

23.  Armas alteram a situação; dano é apenas uma de suas expressões.

24.  Ponto de Vitalidade, Ponto de Inteireza e Ponto de Esforço são os recursos da personagem; Ponto de Urdume é moeda de Desenvolvimento.

25.  Canalização, Tramas, Fragmentos e Selagem preservam sua cosmologia e terminologia estabelecidas.

26.  Desenvolvimento registra mudança; Ponto de Urdume registra capacidade de investimento.

27.  Ponto de Urdume não é recurso de emergência.

28.  Reconhecimento é contextual e nunca um segundo Rank universal.

29.  Reputação sempre pertence a uma rede concreta e traz cobrança proporcional ao acesso que produz.

30.  Pistas Fundamentais não dependem de sucesso arbitrário.

31.  Hipótese interpreta; Contradição reorganiza.

32.  Compasso de Urgência muda a situação, não apaga conhecimento já obtido.

33.  Selagem depende de Ponto de Costura e continuidade fixada.

34.  Puxagem e Refluxo são fenômenos diferentes.

35.  Canalização percorre Aproximação → Tração → Tecitura → Expressão → Relaxamento, ainda que várias etapas ocorram no mesmo Impulso.

36.  Intensidade de Canalização mede profundidade da relação tocada, não simplesmente dano, área ou alcance.

37.  Selagem é aplicação especializada de Canalização, não uma magia separada.

38.  Os valores canônicos de Investigação, Selagem e Canalização presentes no corpo operacional da v2.0 prevalecem; versões anteriores existem apenas no histórico.

39.  NPCs usam apenas o estado que a cena precisa lembrar.

40.  Figurante, Adversário e Ameaça são escalas de presença, não classes de poder.

41.  Magnitude mede escala de impacto, não concede bônus universal.

42.  Costura cria expressão nova; não concede bônus numérico automático.

43.  Quantidade não é Magnitude.

44.  Ameaças usam o mesmo motor de dois Fios.

45.  Uma Ameaça é vencida segundo o objetivo do Conflito, não obrigatoriamente por zerar recursos.

46.  O balanceamento de encontros é estrutural. Dados, Defesas, recursos e custos devem ser lidos com Posição, Pressão, economia de ações e objetivos. A enumeração matemática verifica probabilidades; a avaliação do encontro requer também evidência de mesa.

### Auditoria de fechamento

[2577 TABLE]

Área | Relação-pai | Estado

Resolução | Ação → Motor | fechado

Combate | Situação → Conflito físico | fechado

Defesa | Constituição → limiar | fechado

Dano | Transformação → consequência física | fechado

Recuperação | Transformação → recomposição | fechado

Perseguição | Conflito → Posição + Urgência | fechado

Viagem | Situação → Posição + Urgência + Preparo | fechado

Crafting | Ação → Ofício + Preparo + Expressão | fechado

Social | Ação → Relação + Intervenção | fechado

Investigação | Ação → informação + hipótese | fechado

Reputação | Transformação → permanência social | fechado

Canalização | Expressão → Urdidura + Motor | fechado

Selagem | Expressão → relação fixada + Permanência | fechado

NPCs/Ameaças | Mundo → presença + oposição | fechado

Morte/Colapso | Transformação crítica | fechado

Equilíbrio/Tensão | transformação direcional | fechado

Progressão | Incorporação → Desenvolvimento → PU | fechado

Nenhum desses campos precisa de um segundo motor para funcionar. Catálogos, exemplos e conteúdo podem crescer sem reabrir a arquitetura.

PARTE X
